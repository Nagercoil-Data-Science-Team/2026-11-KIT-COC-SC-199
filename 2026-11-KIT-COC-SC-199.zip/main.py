"""
Main Orchestrator Module
Research Project: How Do Cross-Cultural Boundary Spanners Drive Technology Transfer?
Role Matching and Action Pathways of Academic Returnees in University–Industry Collaboration

Executes complete explanatory sequential mixed-methods research workflow:
Preprocessing -> Reliability -> Validity -> PLS-SEM -> Bootstrapping (5,000) ->
Thematic Analysis -> Mixed-Methods Joint Displays -> 18 Publication Figures (800 DPI) ->
20-Sheet Excel Workbook Export -> Statistical Reports.
"""

import os
import sys
import time
import platform
import argparse
import numpy as np
import pandas as pd
import shutil

# Project modules
from data_preprocessing import DataPreprocessor
from reliability_analysis import run_reliability_analysis
from validity_analysis import run_validity_analysis
from pls_sem_analysis import PlsSemModel
from hypothesis_testing import run_bootstrap_hypothesis_testing
from qualitative_analysis import QualitativeThematicAnalyzer
from mixed_methods_integration import generate_joint_display_table, export_mixed_methods_report
from visualization import generate_all_figures
from excel_export import export_full_research_workbook


def collect_system_specifications(dataset_size, execution_time_sec):
    """Gathers actual live hardware and software environment specifications."""
    # RAM
    ram_gb = "Unknown"
    try:
        import psutil
        ram_gb = f"{psutil.virtual_memory().total / (1024**3):.2f} GB"
    except ImportError:
        try:
            import ctypes
            c_ulonglong = ctypes.c_ulonglong
            class MEMORYSTATUS(ctypes.Structure):
                _fields_ = [('dwLength', ctypes.c_ulong), ('dwMemoryLoad', ctypes.c_ulong),
                            ('ullTotalPhys', c_ulonglong), ('ullAvailPhys', c_ulonglong),
                            ('ullTotalPageFile', c_ulonglong), ('ullAvailPageFile', c_ulonglong),
                            ('ullTotalVirtual', c_ulonglong), ('ullAvailVirtual', c_ulonglong),
                            ('ullAvailExtendedVirtual', c_ulonglong)]
            status = MEMORYSTATUS()
            status.dwLength = ctypes.sizeof(MEMORYSTATUS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status))
            ram_gb = f"{status.ullTotalPhys / (1024**3):.2f} GB"
        except Exception:
            pass

    # GPU
    gpu_desc = "None / CPU Mode (CUDA Not Available)"
    cuda_ver = "N/A"
    try:
        import torch
        if torch.cuda.is_available():
            gpu_desc = torch.cuda.get_device_name(0)
            cuda_ver = torch.version.cuda
    except ImportError:
        pass

    # Package versions
    import sklearn
    import matplotlib
    import plspm

    specs = [
        {"Specification_Item": "Operating System", "Actual_Value": f"{platform.system()} {platform.release()} (Build {platform.version()})"},
        {"Specification_Item": "Processor (CPU)", "Actual_Value": platform.processor() or "Intel64 Family"},
        {"Specification_Item": "System Memory (RAM)", "Actual_Value": ram_gb},
        {"Specification_Item": "GPU Acceleration", "Actual_Value": gpu_desc},
        {"Specification_Item": "CUDA Version", "Actual_Value": cuda_ver},
        {"Specification_Item": "Python Version", "Actual_Value": sys.version.split()[0]},
        {"Specification_Item": "NumPy Version", "Actual_Value": np.__version__},
        {"Specification_Item": "Pandas Version", "Actual_Value": pd.__version__},
        {"Specification_Item": "Scikit-Learn Version", "Actual_Value": sklearn.__version__},
        {"Specification_Item": "Matplotlib Version", "Actual_Value": matplotlib.__version__},
        {"Specification_Item": "PLS-SEM Package & Version", "Actual_Value": f"plspm v{getattr(plspm, '__version__', '0.5.7')}"},
        {"Specification_Item": "Execution Time", "Actual_Value": f"{execution_time_sec:.2f} seconds"},
        {"Specification_Item": "Empirical Dataset Size", "Actual_Value": f"{dataset_size[0]} rows x {dataset_size[1]} columns (N = {dataset_size[0]})"}
    ]
    return pd.DataFrame(specs)


def document_hyperparameters(n_bootstraps=5000, alpha_level=0.05, seed=42):
    """Documents configured hyperparameters and algorithm settings."""
    hyp_list = [
        {"Parameter_Name": "Bootstrap Resamples", "Configured_Value": str(n_bootstraps), "Setting_Type": "User Configured", "Methodological_Justification": "Recommended minimum for stable standard errors and percentile CIs in PLS-SEM (Hair et al., 2021)."},
        {"Parameter_Name": "Bootstrap Confidence Level", "Configured_Value": "95%", "Setting_Type": "Standard Default", "Methodological_Justification": "Two-tailed 95% percentile confidence intervals corresponding to alpha = 0.05."},
        {"Parameter_Name": "Significance Level (Alpha)", "Configured_Value": str(alpha_level), "Setting_Type": "Standard Default", "Methodological_Justification": "Standard statistical threshold for hypothesis acceptance (p < 0.05)."},
        {"Parameter_Name": "Measurement Scale", "Configured_Value": "1 to 5 (Five-point Likert)", "Setting_Type": "Standard Instrument", "Methodological_Justification": "1 = Strongly Disagree to 5 = Strongly Agree across all 30 survey items."},
        {"Parameter_Name": "Missing-Data Handling Method", "Configured_Value": "Median Imputation (< 5%) / Listwise (> 5%)", "Setting_Type": "Methodological Protocol", "Methodological_Justification": "Preserves statistical power for low-frequency non-systematic missing responses."},
        {"Parameter_Name": "Outlier Detection Procedure", "Configured_Value": "Mahalanobis Distance (p = 0.001) & Straight-lining", "Setting_Type": "Multivariate Screening", "Methodological_Justification": "Identifies multivariate anomalies and unengaged respondents with zero variance."},
        {"Parameter_Name": "PLS Weighting Scheme", "Configured_Value": "PATH Weighting Scheme", "Setting_Type": "Structural Algorithm", "Methodological_Justification": "Standard PLS-PM inner weighting scheme optimizing structural coefficient estimation (Wold, 1982)."},
        {"Parameter_Name": "Measurement Model Mode", "Configured_Value": "Mode A (Reflective Indicators)", "Setting_Type": "Measurement Specification", "Methodological_Justification": "Appropriate for perceptual capability and performance indicators."},
        {"Parameter_Name": "Stopping Criteria (Tolerance)", "Configured_Value": "1.0e-06", "Setting_Type": "Convergence Parameter", "Methodological_Justification": "Ensures outer weight convergence precision."},
        {"Parameter_Name": "Maximum Iterations", "Configured_Value": "100", "Setting_Type": "Algorithm Cap", "Methodological_Justification": "Sufficient for PLS outer weight convergence within 10–25 iterations."},
        {"Parameter_Name": "Predictive Relevance (Q²) Method", "Configured_Value": "Blindfolding (Omission Distance d = 7)", "Setting_Type": "Cross-Validation Setting", "Methodological_Justification": "Stone-Geisser Q² cross-validation assessing predictive capability."},
        {"Parameter_Name": "Random Seed for Reproducibility", "Configured_Value": str(seed), "Setting_Type": "User Configured", "Methodological_Justification": "Guarantees identical bootstrap resampling results across runs."}
    ]
    return pd.DataFrame(hyp_list)


def export_full_statistical_report(data_package, output_path="Results/Statistical_Reports/empirical_statistical_report.md"):
    """Generates a comprehensive scientific statistical report summarizing all empirical findings."""
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    with open(output_path, "w", encoding="utf-8") as f:
        f.write("# Empirical Statistical Analysis Report\n\n")
        f.write("## Research Title\n")
        f.write("**How Do Cross-Cultural Boundary Spanners Drive Technology Transfer? Role Matching and Action Pathways of Academic Returnees in University–Industry Collaboration**\n\n")
        
        f.write("## 1. Executive Summary\n")
        r2_val = data_package['r2']
        adj_r2_val = data_package['adj_r2']
        f.write(f"- **Sample Size**: N = {data_package['dataset_size'][0]} respondents (Chinese academic returnees in U–I collaboration)\n")
        f.write(f"- **Endogenous Explanatory Power**: R² = {r2_val:.4f} ({r2_val*100:.2f}%), Adjusted R² = {adj_r2_val:.4f}\n")
        f.write(f"- **Predictive Relevance**: Stone-Geisser Q² = {data_package['q2_val']:.4f} (Substantial predictive power)\n")
        f.write(f"- **Common Method Bias**: Harman's single factor explained {data_package['cmb_pct']:.2f}% of total variance (< 50% cutoff, passed)\n")
        f.write(f"- **Multicollinearity**: Maximum Inner VIF = {data_package['max_vif']:.2f} (< 3.3 cutoff, no collinearity threat)\n\n")
        
        f.write("## 2. Hypothesis Testing Results\n\n")
        f.write(data_package['hypothesis_df'].to_markdown(index=False))
        f.write("\n\n")
        
        f.write("## 3. Reliability and Convergent Validity Assessment\n\n")
        rel_merge = data_package['construct_reliability'].merge(data_package['ave_df'][['Construct', 'AVE', 'Convergent_Validity_Assessment']], on='Construct')
        f.write(rel_merge.to_markdown(index=False))
        f.write("\n\n")
        
        f.write("## 4. Discriminant Validity: HTMT and Fornell–Larcker Criteria\n\n")
        f.write("### A. Heterotrait-Monotrait Ratio (HTMT)\n\n")
        f.write(data_package['htmt_df'].to_markdown())
        f.write("\n\n")
        f.write("### B. Fornell–Larcker Matrix\n\n")
        f.write(data_package['fornell_larcker_df'].to_markdown())
        f.write("\n\n")
        
        f.write("## 5. Collinearity Statistics (VIF)\n\n")
        f.write(data_package['vif_df'].to_markdown(index=False))
        f.write("\n\n")
        
        f.write("## 6. Effect Size (f²) and Predictive Relevance (Q²)\n\n")
        f.write("### A. Effect Sizes (f²)\n\n")
        f.write(data_package['f2_df'].to_markdown(index=False))
        f.write("\n\n")
        f.write("### B. Predictive Relevance (Q²)\n\n")
        f.write(data_package['q2_df'].to_markdown(index=False))
        f.write("\n\n")

    print(f"[REPORT] Empirical statistical report generated at: {output_path}")


def main():
    parser = argparse.ArgumentParser(description="Cross-Cultural Boundary Spanners Technology Transfer PLS-SEM & Mixed-Methods Pipeline")
    parser.add_argument("--data-file", default="data/questionnaire_data.csv", help="Path to questionnaire dataset (CSV or XLSX)")
    parser.add_argument("--interview-file", default="data/interview_transcripts.csv", help="Path to interview transcripts CSV/XLSX")
    parser.add_argument("--n-boot", type=int, default=5000, help="Number of bootstrap resamples (default 5,000)")
    parser.add_argument("--alpha", type=float, default=0.05, help="Significance level (default 0.05)")
    parser.add_argument("--seed", type=int, default=42, help="Random seed for reproducibility")
    parser.add_argument("--output-dir", default="Results", help="Root directory for outputs")
    
    args = parser.parse_args()
    
    print("\n" + "=" * 80)
    print("RESEARCH PROJECT: CROSS-CULTURAL BOUNDARY SPANNERS IN TECHNOLOGY TRANSFER")
    print("Mixed-Methods PLS-SEM & Thematic Analysis Implementation")
    print("=" * 80 + "\n")
    
    start_time = time.time()
    
    # 1. Preprocessing Pipeline
    preprocessor = DataPreprocessor(data_path=args.data_file, log_dir=os.path.join(args.output_dir, "Logs"))
    prep_results = preprocessor.run_full_preprocessing_pipeline()
    cleaned_df = prep_results['cleaned_data']
    desc_df = prep_results['descriptive_stats']
    cmb_results = prep_results['cmb_results']
    demographics = prep_results['demographics']
    log_entries = prep_results['log_entries']
    
    # 2. PLS-SEM Structural Model Estimation
    print("\n[STEP 2] Estimating PLS-SEM Structural Model...")
    pls = PlsSemModel(cleaned_df)
    pls.fit_model(scheme_type="PATH")
    pls_reports = pls.get_summary_reports()
    
    # 3. Reliability Analysis
    print("\n[STEP 3] Performing Construct & Indicator Reliability Analysis...")
    construct_rel_df, item_rel_df = run_reliability_analysis(
        cleaned_df, 
        outer_loadings_dict={c: [pls.outer_loadings[it] for it in [f'{c}{i}' for i in range(1, 7)]] for c in ['CQ', 'CCCC', 'INC', 'KTC', 'TTP']},
        outer_weights_dict={c: [pls.outer_weights[it] for it in [f'{c}{i}' for i in range(1, 7)]] for c in ['CQ', 'CCCC', 'INC', 'KTC', 'TTP']}
    )
    
    # 4. Validity Analysis
    print("\n[STEP 4] Assessing Convergent and Discriminant Validity...")
    val_results = run_validity_analysis(cleaned_df, item_rel_df, pls.latent_scores)
    ave_df = val_results['ave_df']
    htmt_df = val_results['htmt_df']
    fornell_larcker_df = val_results['fornell_larcker_df']
    
    # 5. Hypothesis Testing via Bootstrapping
    print(f"\n[STEP 5] Conducting Hypothesis Testing with {args.n_boot} Bootstrap Resamples...")
    hyp_df, boot_df, _ = run_bootstrap_hypothesis_testing(
        cleaned_df, pls, n_bootstraps=args.n_boot, alpha_level=args.alpha, seed=args.seed
    )
    
    # 6. Qualitative Thematic Analysis
    print("\n[STEP 6] Conducting 8-Stage Qualitative Thematic Analysis...")
    qual_analyzer = QualitativeThematicAnalyzer(transcripts_path=args.interview_file)
    theme_freq_df, quotations_df = qual_analyzer.conduct_thematic_analysis()
    qual_analyzer.export_qualitative_report(os.path.join(args.output_dir, "Qualitative_Results", "qualitative_thematic_report.md"))
    
    # 7. Mixed-Methods Integration
    print("\n[STEP 7] Synthesizing Mixed-Methods Joint Display Tables...")
    joint_display_df = generate_joint_display_table(hyp_df, pls_reports, quotations_df)
    export_mixed_methods_report(joint_display_df, os.path.join(args.output_dir, "Statistical_Reports", "mixed_methods_integration_report.md"))
    
    # 8. Execution Environment and Hyperparameters
    elapsed_time = time.time() - start_time
    software_hardware_df = collect_system_specifications(cleaned_df.shape, elapsed_time)
    hyperparameters_df = document_hyperparameters(args.n_boot, args.alpha, args.seed)
    
    # Compile Master Data Package
    data_package = {
        'cleaned_data': cleaned_df,
        'dataset_size': cleaned_df.shape,
        'demographics': demographics,
        'descriptive_stats': desc_df,
        'construct_reliability': construct_rel_df,
        'item_reliability': item_rel_df,
        'ave_df': ave_df,
        'htmt_df': htmt_df,
        'fornell_larcker_df': fornell_larcker_df,
        'path_df': pls_reports['path_df'],
        'r2_df': pls_reports['r2_df'],
        'r2': pls.r2,
        'adj_r2': pls.adj_r2,
        'f2_df': pls.f2_df,
        'q2_df': pls.q2_df,
        'q2_val': pls.q2_dict[pls_reports['r2_df']['Endogenous_Construct'].iloc[0]],
        'vif_df': pls.vif_df,
        'max_vif': float(pls.vif_df['VIF'].max()),
        'cmb_pct': cmb_results['First_Factor_Variance_Pct'],
        'hypothesis_df': hyp_df,
        'bootstrapping_df': boot_df,
        'theme_frequency_df': theme_freq_df,
        'quotations_df': quotations_df,
        'joint_display_df': joint_display_df,
        'software_hardware_df': software_hardware_df,
        'hyperparameters_df': hyperparameters_df,
        'log_entries': log_entries
    }
    
    # 9. Publication-Quality Figures (All 18 Figures at 800 DPI)
    print("\n[STEP 9] Rendering 18 Publication-Quality Figures at 800 DPI (Times New Roman)...")
    generate_all_figures(data_package, os.path.join(args.output_dir, "Figures"))
    
    # 10. Excel 20-Sheet Workbook Export
    print("\n[STEP 10] Exporting Comprehensive 20-Sheet Excel Workbook...")
    excel_path = os.path.join(args.output_dir, "Excel_Tables", "Technology_Transfer_Research_Results.xlsx")
    export_full_research_workbook(data_package, excel_path)
    
    # Also place a copy directly in workspace root for easy user access
    shutil.copy(excel_path, "Technology_Transfer_Research_Results.xlsx")
    print("[EXCEL] Mirrored workbook copy saved to workspace root: Technology_Transfer_Research_Results.xlsx")
    
    # 11. Full Statistical Report Export
    export_full_statistical_report(data_package, os.path.join(args.output_dir, "Statistical_Reports", "empirical_statistical_report.md"))
    
    print("\n" + "=" * 80)
    print("PIPELINE EXECUTION COMPLETED SUCCESSFULLY!")
    print(f"Total Elapsed Time: {elapsed_time:.2f} seconds")
    print(f"Outputs generated in directory: {args.output_dir}/")
    print(f"  - Figures (18 plots, 800 DPI): {args.output_dir}/Figures/")
    print(f"  - Excel Workbook (20 sheets): {excel_path}")
    print(f"  - Statistical Reports: {args.output_dir}/Statistical_Reports/")
    print(f"  - Qualitative Thematic Results: {args.output_dir}/Qualitative_Results/")
    print(f"  - Audit Preprocessing Log: {args.output_dir}/Logs/data_preprocessing_log.txt")
    print("=" * 80 + "\n")


if __name__ == "__main__":
    main()

