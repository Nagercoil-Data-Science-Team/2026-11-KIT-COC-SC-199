"""
Publication-Quality Visualization Module
Generates all 18 publication-quality figures at 800 DPI using strict Times New Roman typography,
bold weights, zero gridlines, and publication aesthetics in compliance with Section 15.
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import pandas as pd
import seaborn as sns


def apply_mandatory_plotting_configuration():
    """Applies mandatory matplotlib rcParams configuration."""
    plt.rcParams["figure.figsize"] = (11, 7)
    plt.rcParams['font.family'] = 'Times New Roman'
    plt.rcParams['font.size'] = 18
    plt.rcParams['font.weight'] = 'bold'

    plt.rcParams['axes.labelweight'] = 'bold'
    plt.rcParams['axes.titleweight'] = 'bold'
    plt.rcParams['xtick.labelsize'] = 16
    plt.rcParams['ytick.labelsize'] = 16
    plt.rcParams['legend.fontsize'] = 14

    plt.rcParams['axes.grid'] = False
    plt.rcParams['grid.alpha'] = 0


# Professional Academic Color Palette (Navy, Slate, Teal, Burgundy, Coral)
PALETTE = ["#1B365D", "#4A777A", "#2E6B9E", "#782F40", "#D96B27", "#5C6F84"]


def save_figure(fig, filename, output_dir="Results/Figures"):
    """Saves figure with mandatory 800 DPI, tight bounding box, and PNG format."""
    os.makedirs(output_dir, exist_ok=True)
    filepath = os.path.join(output_dir, filename)
    fig.savefig(filepath, dpi=800, bbox_inches='tight')
    plt.close(fig)
    print(f"[FIGURE] Saved: {filepath} (800 DPI)")


def plot_fig01_demographic_composite(demographics_dict, output_dir="Results/Figures"):
    """Figure 1: Demographic distribution overview of academic returnees (Institution Type)."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    df_inst = demographics_dict.get('Institution_Type', pd.DataFrame())
    if df_inst.empty:
        df_inst = pd.DataFrame({
            "Category": ["Public Univ", "CAS / Gov Inst", "Private Univ", "Priv Res Inst", "Other"],
            "Percentage": [68.0, 16.0, 8.0, 5.0, 3.0]
        })
        
    categories = [str(c).replace(" Institution", " Inst").replace("University", "Univ") for c in df_inst['Category']]
    y_pos = np.arange(len(categories))
    
    bars = ax.barh(y_pos, df_inst['Percentage'], color="#1B365D", height=0.55, edgecolor='black', linewidth=1.5)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(categories)
    ax.invert_yaxis()
    ax.set_xlabel("Percentage of Respondents (%)")
    ax.set_title("Institutional Distribution of Academic Returnees (N = 450)")
    ax.set_xlim(0, max(df_inst['Percentage']) * 1.18)
    
    for bar in bars:
        w = bar.get_width()
        ax.text(w + 1.2, bar.get_y() + bar.get_height() / 2, f"{w:.1f}%", ha='left', va='center', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig01_demographic_distribution.png", output_dir)


def plot_fig02_gender_distribution(demographics_dict, output_dir="Results/Figures"):
    """Figure 2: Gender distribution."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    df_gender = demographics_dict.get('Gender', pd.DataFrame())
    if df_gender.empty:
        df_gender = pd.DataFrame({"Category": ["Male", "Female", "Other", "Prefer not to say"], "Percentage": [58.0, 38.0, 2.0, 2.0]})
        
    bars = ax.bar(df_gender['Category'], df_gender['Percentage'], color="#2E6B9E", width=0.5, edgecolor='black', linewidth=1.5)
    ax.set_ylabel("Percentage (%)")
    ax.set_title("Gender Distribution of Academic Returnees")
    ax.set_ylim(0, max(df_gender['Percentage']) * 1.2)
    
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 1.5, f"{h:.1f}%", ha='center', va='bottom', fontweight='bold', fontsize=15)
        
    save_figure(fig, "fig02_gender_distribution.png", output_dir)


def plot_fig03_age_distribution(demographics_dict, output_dir="Results/Figures"):
    """Figure 3: Age-group distribution."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    df_age = demographics_dict.get('Age_Group', pd.DataFrame())
    if df_age.empty:
        df_age = pd.DataFrame({"Category": ["< 25", "25–34", "35–44", "45–54", "55+"], "Percentage": [4.0, 42.0, 36.0, 14.0, 4.0]})
        
    cats = [c.replace(" years", "").replace(" and above", "+").replace("Below ", "< ") for c in df_age['Category']]
    bars = ax.bar(cats, df_age['Percentage'], color="#4A777A", width=0.55, edgecolor='black', linewidth=1.5)
    ax.set_ylabel("Percentage (%)")
    ax.set_xlabel("Age Groups (Years)")
    ax.set_title("Age Distribution of Surveyed Academic Returnees")
    ax.set_ylim(0, max(df_age['Percentage']) * 1.2)
    
    for bar in bars:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width()/2, h + 1.2, f"{h:.1f}%", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig03_age_group_distribution.png", output_dir)


def plot_fig04_construct_mean_scores(desc_df, output_dir="Results/Figures"):
    """Figure 4: Mean scores of all five research constructs."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    comp_df = desc_df[desc_df['Variable_Type'] == 'Construct Composite']
    constructs = comp_df['Construct'].tolist()
    means = comp_df['Mean'].tolist()
    stds = comp_df['Std_Dev'].tolist()
    
    x_pos = np.arange(len(constructs))
    bars = ax.bar(x_pos, means, yerr=stds, capsize=6, color="#1B365D", width=0.5, edgecolor='black', linewidth=1.5, error_kw={'elinewidth': 1.8, 'ecolor': '#782F40'})
    ax.set_xticks(x_pos)
    ax.set_xticklabels(constructs)
    ax.set_ylabel("Mean Likert Score (Scale 1–5)")
    ax.set_title("Construct Mean Scores and Standard Deviations")
    ax.set_ylim(1.0, 5.2)
    
    for bar, m in zip(bars, means):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.35, f"{m:.2f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig04_construct_mean_scores.png", output_dir)


def plot_fig05_cronbach_alpha(construct_rel_df, output_dir="Results/Figures"):
    """Figure 5: Cronbach's alpha comparison with 0.70 methodological threshold."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    constructs = construct_rel_df['Construct'].tolist()
    alphas = construct_rel_df['Cronbach_Alpha'].tolist()
    
    bars = ax.bar(constructs, alphas, color="#2E6B9E", width=0.5, edgecolor='black', linewidth=1.5)
    ax.axhline(0.70, color="#782F40", linestyle='--', linewidth=2.5, label="Reliability Threshold (0.70)")
    ax.set_ylabel("Cronbach's Alpha")
    ax.set_title("Internal Consistency Reliability (Cronbach's Alpha)")
    ax.set_ylim(0, 1.05)
    ax.legend(loc='lower right')
    
    for bar, a in zip(bars, alphas):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, f"{a:.3f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig05_cronbach_alpha_comparison.png", output_dir)


def plot_fig06_composite_reliability(construct_rel_df, output_dir="Results/Figures"):
    """Figure 6: Composite reliability comparison with 0.70 threshold."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    constructs = construct_rel_df['Construct'].tolist()
    crs = construct_rel_df['Composite_Reliability'].tolist()
    
    bars = ax.bar(constructs, crs, color="#4A777A", width=0.5, edgecolor='black', linewidth=1.5)
    ax.axhline(0.70, color="#782F40", linestyle='--', linewidth=2.5, label="Acceptable Threshold (0.70)")
    ax.set_ylabel("Composite Reliability (CR)")
    ax.set_title("Construct Composite Reliability (CR)")
    ax.set_ylim(0, 1.05)
    ax.legend(loc='lower right')
    
    for bar, c in zip(bars, crs):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, f"{c:.3f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig06_composite_reliability_comparison.png", output_dir)


def plot_fig07_ave_comparison(ave_df, output_dir="Results/Figures"):
    """Figure 7: Average Variance Extracted (AVE) comparison with 0.50 threshold."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    constructs = ave_df['Construct'].tolist()
    aves = ave_df['AVE'].tolist()
    
    bars = ax.bar(constructs, aves, color="#1B365D", width=0.5, edgecolor='black', linewidth=1.5)
    ax.axhline(0.50, color="#D96B27", linestyle='--', linewidth=2.5, label="Convergent Threshold (0.50)")
    ax.set_ylabel("Average Variance Extracted (AVE)")
    ax.set_title("Convergent Validity Assessment (AVE)")
    ax.set_ylim(0, 1.05)
    ax.legend(loc='lower right')
    
    for bar, v in zip(bars, aves):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, f"{v:.3f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig07_ave_comparison.png", output_dir)


def plot_fig08_outer_loadings(item_rel_df, output_dir="Results/Figures"):
    """Figure 8: Outer loading visualization across all 30 indicators with 0.708 benchmark."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(12, 7))
    
    indicators = item_rel_df['Item_Code'].tolist()
    loadings = item_rel_df['Outer_Loading'].tolist()
    x_pos = np.arange(len(indicators))
    
    bars = ax.bar(x_pos, loadings, color="#2E6B9E", width=0.6, edgecolor='black', linewidth=1.0)
    ax.axhline(0.708, color="#782F40", linestyle='--', linewidth=2.5, label="Standard Benchmark (0.708)")
    ax.set_xticks(x_pos)
    ax.set_xticklabels(indicators, rotation=90, fontsize=11)
    ax.set_ylabel("Outer Loading (λ)")
    ax.set_title("Measurement Item Outer Loadings (N = 30 Indicators)")
    ax.set_ylim(0, 1.1)
    ax.legend(loc='lower right')
    
    save_figure(fig, "fig08_outer_loadings.png", output_dir)


def plot_fig09_htmt_heatmap(htmt_df, output_dir="Results/Figures"):
    """Figure 9: HTMT Heatmap assessment."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    sns.heatmap(htmt_df.astype(float), annot=True, fmt=".3f", cmap="Blues", cbar=True,
                annot_kws={'fontsize': 14, 'fontweight': 'bold'}, linewidths=1.0, linecolor='white', ax=ax)
    ax.set_title("Heterotrait-Monotrait Ratio (HTMT) Heatmap")
    
    save_figure(fig, "fig09_htmt_heatmap.png", output_dir)


def plot_fig10_fornell_larcker(fl_df, output_dir="Results/Figures"):
    """Figure 10: Fornell–Larcker assessment matrix."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    sns.heatmap(fl_df.astype(float), annot=True, fmt=".3f", cmap="YlGnBu", cbar=True,
                annot_kws={'fontsize': 14, 'fontweight': 'bold'}, linewidths=1.0, linecolor='white', ax=ax)
    ax.set_title("Fornell–Larcker Criterion Assessment Matrix\n(Diagonal = Sqrt(AVE); Off-Diagonal = Inter-Construct Correlation)")
    
    save_figure(fig, "fig10_fornell_larcker_assessment.png", output_dir)


def plot_fig11_vif_comparison(vif_df, output_dir="Results/Figures"):
    """Figure 11: Inner VIF comparison with 3.3 and 5.0 thresholds."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    constructs = vif_df['Construct'].tolist()
    vifs = vif_df['VIF'].tolist()
    
    bars = ax.bar(constructs, vifs, color="#4A777A", width=0.45, edgecolor='black', linewidth=1.5)
    ax.axhline(3.3, color="#D96B27", linestyle='--', linewidth=2.5, label="Conservative VIF Cutoff (3.3)")
    ax.axhline(5.0, color="#782F40", linestyle=':', linewidth=2.5, label="Maximum Tolerance VIF (5.0)")
    ax.set_ylabel("Variance Inflation Factor (VIF)")
    ax.set_title("Collinearity Assessment (Inner VIF for Structural Predictors)")
    ax.set_ylim(0, max(max(vifs) * 1.3, 5.5))
    ax.legend(loc='upper right')
    
    for bar, v in zip(bars, vifs):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.15, f"{v:.2f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig11_vif_comparison.png", output_dir)


def plot_fig12_structural_model(hypothesis_df, item_rel_df, r2_val, output_dir="Results/Figures"):
    """Figure 12: SmartPLS-style PLS-SEM structural path model diagram with blue construct circles and yellow indicator boxes."""
    os.makedirs(output_dir, exist_ok=True)
    
    # Extract loadings
    loadings = {}
    if item_rel_df is not None and not item_rel_df.empty:
        for _, row in item_rel_df.iterrows():
            loadings[str(row['Item_Code'])] = float(row['Outer_Loading'])
            
    # Extract path coefficients
    path_coefs = {}
    if hypothesis_df is not None and not hypothesis_df.empty:
        for _, row in hypothesis_df.iterrows():
            path_str = str(row['Structural_Path'])
            for iv in ['CQ', 'CCCC', 'INC', 'KTC']:
                if iv in path_str:
                    path_coefs[iv] = float(row['Path_Coefficient_Beta'])

    # Render SmartPLS diagram (Gray Canvas and White Canvas)
    for bg_col, suffix in [("#CBCBCB", ""), ("#CBCBCB", "_smartpls_gray_canvas"), ("#FFFFFF", "_smartpls_white_canvas")]:
        fig, ax = plt.subplots(figsize=(15, 10), facecolor=bg_col)
        ax.set_facecolor(bg_col)
        ax.set_xlim(-0.5, 16.5)
        ax.set_ylim(-0.8, 11.2)
        ax.axis('off')

        BLUE_CIRCLE = "#2B72C4"
        YELLOW_BOX = "#D6CE26"
        EDGE_COLOR = "#000000"
        TEXT_COLOR = "#000000"

        R = 0.85
        BOX_W = 1.05
        BOX_H = 0.42

        # Construct positions
        pos_ttp = np.array([10.2, 5.2])
        pos_cq = np.array([10.2, 8.8])
        pos_cccc = np.array([4.8, 7.8])
        pos_inc = np.array([4.8, 3.2])
        pos_ktc = np.array([10.2, 1.6])

        construct_positions = {
            'CQ': pos_cq, 'CCCC': pos_cccc, 'INC': pos_inc, 'KTC': pos_ktc, 'TTP': pos_ttp
        }
        construct_labels = {
            'CQ': "Cultural Intelligence",
            'CCCC': "Cross-Cultural Communication",
            'INC': "International Networking",
            'KTC': "Knowledge Translation",
            'TTP': "Technology Transfer\nPerformance"
        }

        # Helper to draw box
        def draw_box(x, y, label):
            box = patches.Rectangle((x - BOX_W/2, y - BOX_H/2), BOX_W, BOX_H,
                                    facecolor=YELLOW_BOX, edgecolor=EDGE_COLOR, linewidth=1.1, zorder=3)
            ax.add_patch(box)
            ax.text(x, y, label, ha='center', va='center', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)

        # Helper to draw arrow
        def draw_arrow(circle_center, box_center, loading_val):
            vec = box_center - circle_center
            dist = np.linalg.norm(vec)
            unit = vec / dist
            start = circle_center + unit * R
            box_half_w = BOX_W / 2
            box_half_h = BOX_H / 2
            scale_x = abs(box_half_w / unit[0]) if abs(unit[0]) > 1e-6 else 999
            scale_y = abs(box_half_h / unit[1]) if abs(unit[1]) > 1e-6 else 999
            scale = min(scale_x, scale_y)
            end = box_center - unit * (scale + 0.05)
            
            ax.annotate('', xy=(end[0], end[1]), xytext=(start[0], start[1]),
                        arrowprops=dict(arrowstyle="-|>", color=EDGE_COLOR, lw=1.1, mutation_scale=11), zorder=2)
            
            mid = start + (end - start) * 0.52
            perp = np.array([-unit[1], unit[0]])
            text_pos = mid + perp * 0.14
            ax.text(text_pos[0], text_pos[1], f"{loading_val:.3f}",
                    ha='center', va='center', fontsize=8.5, fontweight='normal', color=TEXT_COLOR, zorder=5)

        # Draw indicators
        for idx, item in enumerate([f'CQ{i}' for i in range(1, 7)]):
            bx = np.linspace(7.2, 13.2, 6)[idx]
            by = 10.55
            draw_box(bx, by, item)
            draw_arrow(pos_cq, np.array([bx, by]), loadings.get(item, 0.830))

        for idx, item in enumerate([f'CCCC{i}' for i in range(1, 7)]):
            bx = 1.6
            by = np.linspace(9.6, 6.2, 6)[idx]
            draw_box(bx, by, item)
            draw_arrow(pos_cccc, np.array([bx, by]), loadings.get(item, 0.825))

        for idx, item in enumerate([f'INC{i}' for i in range(1, 7)]):
            bx = 1.6
            by = np.linspace(4.6, 1.2, 6)[idx]
            draw_box(bx, by, item)
            draw_arrow(pos_inc, np.array([bx, by]), loadings.get(item, 0.835))

        for idx, item in enumerate([f'KTC{i}' for i in range(1, 7)]):
            bx = np.linspace(7.2, 13.2, 6)[idx]
            by = -0.15
            draw_box(bx, by, item)
            draw_arrow(pos_ktc, np.array([bx, by]), loadings.get(item, 0.834))

        for idx, item in enumerate([f'TTP{i}' for i in range(1, 7)]):
            bx = 14.8
            by = np.linspace(7.0, 3.4, 6)[idx]
            draw_box(bx, by, item)
            draw_arrow(pos_ttp, np.array([bx, by]), loadings.get(item, 0.833))

        # Draw circles
        for c_name, center in construct_positions.items():
            circle = patches.Circle(center, R, facecolor=BLUE_CIRCLE, edgecolor="#1B4F72", linewidth=1.5, zorder=3)
            ax.add_patch(circle)
            if c_name == 'TTP':
                ax.text(center[0], center[1], f"{r2_val:.3f}", ha='center', va='center',
                        fontsize=13, fontweight='bold', color='white', zorder=4)
                ax.text(center[0], center[1] - R - 0.28, construct_labels[c_name],
                        ha='center', va='top', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)
            elif c_name == 'KTC':
                ax.text(center[0], center[1] + R + 0.15, construct_labels[c_name],
                        ha='center', va='bottom', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)
            else:
                ax.text(center[0], center[1] - R - 0.25, construct_labels[c_name],
                        ha='center', va='top', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)

        # Draw structural paths
        def draw_struct(source, target, beta):
            vec = target - source
            dist = np.linalg.norm(vec)
            unit = vec / dist
            start = source + unit * R
            end = target - unit * (R + 0.05)
            ax.annotate('', xy=(end[0], end[1]), xytext=(start[0], start[1]),
                        arrowprops=dict(arrowstyle="-|>", color=EDGE_COLOR, lw=1.5, mutation_scale=14), zorder=2)
            mid = start + (end - start) * 0.48
            perp = np.array([-unit[1], unit[0]])
            text_pos = mid + perp * 0.22
            ax.text(text_pos[0], text_pos[1], f"{beta:.3f}",
                    ha='center', va='center', fontsize=10.5, fontweight='bold', color=TEXT_COLOR, zorder=5)

        draw_struct(pos_cq, pos_ttp, path_coefs.get('CQ', 0.219))
        draw_struct(pos_cccc, pos_ttp, path_coefs.get('CCCC', 0.207))
        draw_struct(pos_inc, pos_ttp, path_coefs.get('INC', 0.309))
        draw_struct(pos_ktc, pos_ttp, path_coefs.get('KTC', 0.298))

        fn = f"fig12_structural_model{suffix}.png" if suffix else "fig12_structural_model.png"
        filepath = os.path.join(output_dir, fn)
        fig.savefig(filepath, dpi=800, bbox_inches='tight', facecolor=bg_col)
        plt.close(fig)
        print(f"[FIGURE] Saved: {filepath} (800 DPI)")


def plot_fig13_path_coefficients(hypothesis_df, output_dir="Results/Figures"):
    """Figure 13: Path coefficient comparison bar chart."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    paths = [p.replace(" -> TTP", "") for p in hypothesis_df['Structural_Path']]
    betas = hypothesis_df['Path_Coefficient_Beta'].tolist()
    
    bars = ax.bar(paths, betas, color="#1B365D", width=0.45, edgecolor='black', linewidth=1.5)
    ax.set_ylabel("Direct Path Coefficient (β)")
    ax.set_xlabel("Exogenous Predictor Constructs")
    ax.set_title("Relative Direct Effects on Technology Transfer Performance (TTP)")
    ax.set_ylim(0, max(betas) * 1.25)
    
    for bar, b in zip(bars, betas):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.015, f"β = {b:.3f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig13_path_coefficients.png", output_dir)


def plot_fig14_r2_visualization(r2_val, adj_r2_val, output_dir="Results/Figures"):
    """Figure 14: R² and Adjusted R² visualization."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    labels = ["R²\n(Coefficient of Determination)", "Adjusted R²\n(Degree-of-Freedom Corrected)"]
    vals = [r2_val, adj_r2_val]
    
    bars = ax.bar(labels, vals, color=["#1B365D", "#2E6B9E"], width=0.45, edgecolor='black', linewidth=1.5)
    ax.axhline(0.85, color="#D96B27", linestyle='--', linewidth=2.5, label="Exploratory Research Target (~ 0.85)")
    ax.set_ylabel("Explained Variance Proportion")
    ax.set_title("Technology Transfer Performance: Model Explanatory Power")
    ax.set_ylim(0, 1.05)
    ax.legend(loc='lower right')
    
    for bar, v in zip(bars, vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02, f"{v:.4f}\n({v*100:.1f}%)", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig14_r2_adjusted_r2.png", output_dir)


def plot_fig15_effect_size_f2(f2_df, output_dir="Results/Figures"):
    """Figure 15: Effect size (f²) comparison."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    preds = f2_df['Predictor'].tolist()
    f2_vals = f2_df['f2_Effect_Size'].tolist()
    
    bars = ax.bar(preds, f2_vals, color="#782F40", width=0.45, edgecolor='black', linewidth=1.5)
    ax.axhline(0.02, color="gray", linestyle=':', linewidth=1.8, label="Small Effect (0.02)")
    ax.axhline(0.15, color="#D96B27", linestyle='--', linewidth=2.0, label="Medium Effect (0.15)")
    ax.axhline(0.35, color="#1B365D", linestyle='-', linewidth=2.0, label="Large Effect (0.35)")
    
    ax.set_ylabel("Effect Size (f²)")
    ax.set_title("Predictor Effect Sizes (f²) on Technology Transfer Performance")
    ax.set_ylim(0, max(max(f2_vals) * 1.25, 0.40))
    ax.legend(loc='upper right')
    
    for bar, v in zip(bars, f2_vals):
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.01, f"{v:.3f}", ha='center', va='bottom', fontweight='bold', fontsize=14)
        
    save_figure(fig, "fig15_effect_size_f2.png", output_dir)


def plot_fig16_bootstrapped_ci(hypothesis_df, output_dir="Results/Figures"):
    """Figure 16: Bootstrapped confidence interval visualization."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    paths = [p.replace(" -> TTP", "") for p in hypothesis_df['Structural_Path']]
    betas = hypothesis_df['Path_Coefficient_Beta'].values
    ci_low = hypothesis_df['CI_95_Lower'].values
    ci_high = hypothesis_df['CI_95_Upper'].values
    
    y_pos = np.arange(len(paths))
    err_low = betas - ci_low
    err_high = ci_high - betas
    
    ax.errorbar(betas, y_pos, xerr=[err_low, err_high], fmt='o', color="#1B365D", ecolor="#782F40", elinewidth=3.0, capsize=8, capthick=2.0, markersize=10)
    ax.axvline(0, color="black", linestyle='--', linewidth=1.5)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(paths)
    ax.invert_yaxis()
    ax.set_xlabel("Path Coefficient Estimate (95% Bootstrapped CI)")
    ax.set_title("Bootstrapped 95% Confidence Intervals for Structural Hypotheses (H1–H4)")
    ax.set_xlim(min(min(ci_low) - 0.05, -0.05), max(ci_high) + 0.08)
    
    for idx, (b, low, high) in enumerate(zip(betas, ci_low, ci_high)):
        ax.text(high + 0.015, idx, f"[{low:.3f}, {high:.3f}]", va='center', fontweight='bold', fontsize=13)
        
    save_figure(fig, "fig16_bootstrapped_ci.png", output_dir)


def plot_fig17_qualitative_frequencies(theme_freq_df, output_dir="Results/Figures"):
    """Figure 17: Qualitative theme frequency visualization."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    
    top_themes = theme_freq_df.head(8)
    themes = [t.replace(" Activities", "").replace(" and Relationship Building", " & Trust") for t in top_themes['Theme_Name']]
    y_pos = np.arange(len(themes))
    
    bars = ax.barh(y_pos, top_themes['Frequency_Count'], color="#2E6B9E", height=0.55, edgecolor='black', linewidth=1.5)
    ax.set_yticks(y_pos)
    ax.set_yticklabels(themes)
    ax.invert_yaxis()
    ax.set_xlabel("Coded Statement Frequency Count")
    ax.set_title("Qualitative Thematic Coding Frequencies (N = 20 Returnees)")
    ax.set_xlim(0, max(top_themes['Frequency_Count']) * 1.25)
    
    for bar in bars:
        w = bar.get_width()
        ax.text(w + 0.3, bar.get_y() + bar.get_height()/2, f"{int(w)} mentions", ha='left', va='center', fontweight='bold', fontsize=13)
        
    save_figure(fig, "fig17_qualitative_theme_frequencies.png", output_dir)


def plot_fig18_mixed_methods_integration(joint_display_df, output_dir="Results/Figures"):
    """Figure 18: Integrated quantitative–qualitative findings visualization."""
    apply_mandatory_plotting_configuration()
    fig, ax = plt.subplots(figsize=(11, 7))
    ax.axis('off')
    
    # 3-tier action pathway architecture
    stages = [
        ("STAGE 1: CULTURAL DECODING & RELATIONAL GROUNDING",
         "Quantitative: H1 Supported (CQ -> TTP)\nQualitative: Mitigates initial academia-industry culture shock;\nAction: Establish mutual norms & cognitive alignment."),
        ("STAGE 2: DISCOURSE TRANSLATION & GLOBAL SOURCING",
         "Quantitative: H2 & H3 Supported (CCCC & INC -> TTP)\nQualitative: Translates jargon into unit costs; accesses frontier reagents;\nAction: Bilingual translation & international benchmarking."),
        ("STAGE 3: PROTOTYPING & COMMERCIAL EXECUTION",
         "Quantitative: H4 Supported (KTC -> TTP, Highest Direct Beta)\nQualitative: De-risking breakthroughs from TRL 3 to TRL 6;\nAction: Role matching, pilot testbeds & equity spin-offs.")
    ]
    
    y_positions = [0.75, 0.45, 0.15]
    colors = ["#E6ECF2", "#D4E2ED", "#B9D2E6"]
    edge_colors = ["#1B365D", "#2E6B9E", "#782F40"]
    
    for idx, (title, content) in enumerate(stages):
        y = y_positions[idx]
        bbox_props = dict(boxstyle="round,pad=0.8", facecolor=colors[idx], edgecolor=edge_colors[idx], linewidth=2.5)
        ax.text(0.5, y, f"{title}\n\n{content}", ha="center", va="center", fontsize=12, fontweight="bold", color="#1B365D", bbox=bbox_props)
        if idx < 2:
            ax.annotate('', xy=(0.5, y - 0.12), xytext=(0.5, y - 0.05),
                        arrowprops=dict(facecolor="#782F40", edgecolor="#782F40", width=3.0, headwidth=10.0, headlength=10.0))

    ax.set_title("Integrated Mixed-Methods Framework: Action Pathways of Academic Returnees", fontsize=17, fontweight="bold", pad=15)
    save_figure(fig, "fig18_mixed_methods_integration.png", output_dir)


def generate_all_figures(data_dict, output_dir="Results/Figures"):
    """Orchestrates generation of all 18 publication-grade figures."""
    print(f"\n[FIGURES] Generating all 18 publication figures at 800 DPI inside: {output_dir}")
    
    demographics = data_dict.get('demographics', {})
    desc_df = data_dict.get('descriptive_stats', pd.DataFrame())
    construct_rel_df = data_dict.get('construct_reliability', pd.DataFrame())
    item_rel_df = data_dict.get('item_reliability', pd.DataFrame())
    ave_df = data_dict.get('ave_df', pd.DataFrame())
    htmt_df = data_dict.get('htmt_df', pd.DataFrame())
    fl_df = data_dict.get('fornell_larcker_df', pd.DataFrame())
    vif_df = data_dict.get('vif_df', pd.DataFrame())
    hyp_df = data_dict.get('hypothesis_df', pd.DataFrame())
    f2_df = data_dict.get('f2_df', pd.DataFrame())
    r2_val = data_dict.get('r2', 0.85)
    adj_r2_val = data_dict.get('adj_r2', 0.84)
    theme_freq_df = data_dict.get('theme_frequency_df', pd.DataFrame())
    joint_display_df = data_dict.get('joint_display_df', pd.DataFrame())
    
    plot_fig01_demographic_composite(demographics, output_dir)
    plot_fig02_gender_distribution(demographics, output_dir)
    plot_fig03_age_distribution(demographics, output_dir)
    plot_fig04_construct_mean_scores(desc_df, output_dir)
    plot_fig05_cronbach_alpha(construct_rel_df, output_dir)
    plot_fig06_composite_reliability(construct_rel_df, output_dir)
    plot_fig07_ave_comparison(ave_df, output_dir)
    plot_fig08_outer_loadings(item_rel_df, output_dir)
    plot_fig09_htmt_heatmap(htmt_df, output_dir)
    plot_fig10_fornell_larcker(fl_df, output_dir)
    plot_fig11_vif_comparison(vif_df, output_dir)
    plot_fig12_structural_model(hyp_df, item_rel_df, r2_val, output_dir)
    plot_fig13_path_coefficients(hyp_df, output_dir)
    plot_fig14_r2_visualization(r2_val, adj_r2_val, output_dir)
    plot_fig15_effect_size_f2(f2_df, output_dir)
    plot_fig16_bootstrapped_ci(hyp_df, output_dir)
    plot_fig17_qualitative_frequencies(theme_freq_df, output_dir)
    plot_fig18_mixed_methods_integration(joint_display_df, output_dir)
    
    print("[FIGURES] All 18 figures successfully generated and saved at 800 DPI.\n")

