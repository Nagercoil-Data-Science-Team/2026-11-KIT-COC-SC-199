"""
Reliability Analysis Module
Calculates Cronbach's Alpha, Composite Reliability (CR / Dillon-Goldstein's rho),
Dijkstra-Henseler's rho_A, Corrected Item-Total Correlation (CITC), and outer loadings.
"""

import numpy as np
import pandas as pd
from scipy import stats


CONSTRUCT_ITEMS = {
    'CQ': [f'CQ{i}' for i in range(1, 7)],
    'CCCC': [f'CCCC{i}' for i in range(1, 7)],
    'INC': [f'INC{i}' for i in range(1, 7)],
    'KTC': [f'KTC{i}' for i in range(1, 7)],
    'TTP': [f'TTP{i}' for i in range(1, 7)]
}


def calculate_cronbach_alpha(items_df):
    """
    Computes Cronbach's Alpha for a set of items:
    alpha = (k / (k - 1)) * (1 - sum(var_i) / var_total)
    """
    k = items_df.shape[1]
    if k <= 1:
        return 1.0
    item_variances = items_df.var(axis=0, ddof=1).sum()
    total_variance = items_df.sum(axis=1).var(ddof=1)
    if total_variance <= 1e-9:
        return 0.0
    alpha = (k / (k - 1)) * (1 - (item_variances / total_variance))
    return float(alpha)


def calculate_citc(items_df):
    """
    Computes Corrected Item-Total Correlation (CITC) for each indicator:
    Correlation of item_i with (sum of all items - item_i).
    """
    citc_dict = {}
    total_score = items_df.sum(axis=1)
    for col in items_df.columns:
        other_sum = total_score - items_df[col]
        corr, _ = stats.pearsonr(items_df[col], other_sum)
        citc_dict[col] = float(corr)
    return citc_dict


def calculate_rho_a(weights, S):
    """
    Calculates Dijkstra-Henseler's rho_A:
    rho_A = (w'w)^2 * (w'(S - diag(S))w) / (w'(ww' - diag(ww'))w)
    """
    w = np.asarray(weights).reshape(-1, 1)
    w_norm = w / np.sqrt(np.dot(w.T, w))
    
    S_nodiag = S - np.diag(np.diag(S))
    ww = np.dot(w_norm, w_norm.T)
    ww_nodiag = ww - np.diag(np.diag(ww))
    
    num = np.dot(w_norm.T, np.dot(S_nodiag, w_norm))[0, 0]
    den = np.dot(w_norm.T, np.dot(ww_nodiag, w_norm))[0, 0]
    
    if abs(den) < 1e-9:
        return 1.0
    rho_a = float(num / den)
    return max(0.0, min(1.0, rho_a))


def run_reliability_analysis(df, outer_loadings_dict=None, outer_weights_dict=None):
    """
    Conducts comprehensive reliability assessment across all 5 constructs.
    
    Returns:
    - construct_reliability_df: Summary of Alpha, CR, rho_A, and evaluation
    - item_reliability_df: Summary of CITC, Outer Loading, and item evaluation
    """
    construct_summary = []
    item_summary = []

    for construct, items in CONSTRUCT_ITEMS.items():
        sub_df = df[items]
        k = len(items)
        
        # 1. Cronbach's Alpha
        alpha = calculate_cronbach_alpha(sub_df)
        
        # 2. CITC for each item
        citc = calculate_citc(sub_df)
        
        # 3. Outer Loadings
        if outer_loadings_dict and construct in outer_loadings_dict:
            loadings = np.array(outer_loadings_dict[construct])
        else:
            # Fallback: correlation of item with first principal component or sum
            pca_score = stats.zscore(sub_df.sum(axis=1))
            loadings = np.array([stats.pearsonr(sub_df[col], pca_score)[0] for col in items])

        # 4. Composite Reliability (CR / Dillon-Goldstein's rho)
        # CR = (sum lambda)^2 / ((sum lambda)^2 + sum(1 - lambda^2))
        sum_loadings = np.sum(loadings)
        sum_var_err = np.sum(1.0 - loadings**2)
        cr = float((sum_loadings**2) / (sum_loadings**2 + sum_var_err))
        
        # 5. Dijkstra-Henseler's rho_A
        if outer_weights_dict and construct in outer_weights_dict:
            weights = np.array(outer_weights_dict[construct])
        else:
            weights = loadings / np.sum(loadings)
            
        S = np.corrcoef(sub_df.values, rowvar=False)
        rho_a = calculate_rho_a(weights, S)

        # Methodological evaluation
        alpha_eval = "Acceptable (>= 0.70)" if alpha >= 0.70 else "Caution (< 0.70)"
        if 0.75 <= alpha <= 0.85:
            alpha_eval = "Optimal Target Range (0.75–0.85)"
        elif alpha > 0.85 and alpha <= 0.95:
            alpha_eval = "Good / High Reliability (0.85–0.95)"
        elif alpha > 0.95:
            alpha_eval = "Caution: Possible Item Redundancy (> 0.95)"

        cr_eval = "Satisfactory (0.70–0.95)" if 0.70 <= cr <= 0.95 else ("Caution (< 0.70)" if cr < 0.70 else "Item Redundancy (> 0.95)")
        rho_a_eval = "Satisfactory (>= 0.70)" if rho_a >= 0.70 else "Caution (< 0.70)"

        construct_summary.append({
            "Construct": construct,
            "Number_of_Items": k,
            "Cronbach_Alpha": round(alpha, 4),
            "Composite_Reliability": round(cr, 4),
            "rho_A": round(rho_a, 4),
            "Alpha_Evaluation": alpha_eval,
            "CR_Evaluation": cr_eval,
            "rho_A_Evaluation": rho_a_eval,
            "Overall_Internal_Consistency": "Supported" if (alpha >= 0.70 and cr >= 0.70) else "Review Required"
        })

        # Record item-level metrics
        for idx, item in enumerate(items):
            item_load = float(loadings[idx])
            item_citc = citc[item]
            item_summary.append({
                "Construct": construct,
                "Item_Code": item,
                "Corrected_Item_Total_Corr": round(item_citc, 4),
                "Outer_Loading": round(item_load, 4),
                "CITC_Threshold_Met": "Yes (>= 0.40)" if item_citc >= 0.40 else "No (< 0.40)",
                "Loading_Threshold_Met": "Yes (>= 0.708)" if item_load >= 0.708 else "Marginal (0.50-0.70)" if item_load >= 0.50 else "Sub-threshold (< 0.50)"
            })

    construct_rel_df = pd.DataFrame(construct_summary)
    item_rel_df = pd.DataFrame(item_summary)
    
    return construct_rel_df, item_rel_df


if __name__ == "__main__":
    from data_preprocessing import DataPreprocessor
    prep = DataPreprocessor()
    res = prep.run_full_preprocessing_pipeline()
    c_df, i_df = run_reliability_analysis(res['cleaned_data'])
    print("Construct Reliability Summary:\n", c_df)
    print("\nItem Reliability Sample:\n", i_df.head(10))

