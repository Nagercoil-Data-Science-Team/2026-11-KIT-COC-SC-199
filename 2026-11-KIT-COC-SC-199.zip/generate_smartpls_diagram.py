"""
SmartPLS Path Model Diagram Generator
Generates an authentic SmartPLS-style PLS-SEM path diagram matching the user's reference image:
- Characteristic SmartPLS gray canvas background
- Bright royal-blue construct circles
- Yellow indicator rectangle boxes
- Outer loadings on measurement arrows
- Structural path coefficients on regression arrows
- R-squared value prominently displayed inside the endogenous construct circle
"""

import os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np


def draw_smartpls_diagram(loadings, path_coefs, r2_val, output_path="Results/Figures/fig12_structural_model.png", bg_color="#CBCBCB"):
    """
    Renders an authentic SmartPLS-style path diagram.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    
    fig, ax = plt.subplots(figsize=(15, 10), facecolor=bg_color)
    ax.set_facecolor(bg_color)
    ax.set_xlim(-0.5, 16.5)
    ax.set_ylim(-0.8, 11.2)
    ax.axis('off')

    # Color Constants
    BLUE_CIRCLE = "#2B72C4"
    YELLOW_BOX = "#D6CE26"
    EDGE_COLOR = "#000000"
    TEXT_COLOR = "#000000"

    # Circle radius & Box dimensions
    R = 0.85
    BOX_W = 1.05
    BOX_H = 0.42

    # 1. CONSTRUCT POSITIONS (Centers)
    # TTP: Target / Endogenous in the center-right
    pos_ttp = np.array([10.2, 5.2])
    
    # CQ: Top
    pos_cq = np.array([10.2, 8.8])
    
    # CCCC: Upper-Left
    pos_cccc = np.array([4.8, 7.8])
    
    # INC: Lower-Left
    pos_inc = np.array([4.8, 3.2])
    
    # KTC: Bottom
    pos_ktc = np.array([10.2, 1.6])

    construct_positions = {
        'CQ': pos_cq,
        'CCCC': pos_cccc,
        'INC': pos_inc,
        'KTC': pos_ktc,
        'TTP': pos_ttp
    }

    construct_labels = {
        'CQ': "Cultural Intelligence",
        'CCCC': "Cross-Cultural Communication",
        'INC': "International Networking",
        'KTC': "Knowledge Translation",
        'TTP': "Technology Transfer\nPerformance"
    }

    # 2. INDICATOR POSITIONS & ARROW DRAWING
    # Helper to draw box
    def draw_indicator_box(x, y, label):
        box = patches.Rectangle((x - BOX_W/2, y - BOX_H/2), BOX_W, BOX_H,
                                facecolor=YELLOW_BOX, edgecolor=EDGE_COLOR, linewidth=1.1, zorder=3)
        ax.add_patch(box)
        ax.text(x, y, label, ha='center', va='center', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)

    # Helper to draw measurement arrow from circle boundary to box boundary
    def draw_measurement_arrow(circle_center, box_center, loading_val, label_side='mid'):
        # Vector from circle to box
        vec = box_center - circle_center
        dist = np.linalg.norm(vec)
        unit = vec / dist
        
        # Start at circle boundary
        start = circle_center + unit * R
        
        # End at box boundary
        # Check intersection with box rectangle
        # Approximate: end at distance minus half box dimension along direction
        box_half_w = BOX_W / 2
        box_half_h = BOX_H / 2
        # Scale unit vector to box edge
        scale_x = abs(box_half_w / unit[0]) if abs(unit[0]) > 1e-6 else 999
        scale_y = abs(box_half_h / unit[1]) if abs(unit[1]) > 1e-6 else 999
        scale = min(scale_x, scale_y)
        end = box_center - unit * (scale + 0.05)
        
        # Arrow
        ax.annotate('', xy=(end[0], end[1]), xytext=(start[0], start[1]),
                    arrowprops=dict(arrowstyle="-|>", color=EDGE_COLOR, lw=1.1, mutation_scale=11), zorder=2)
        
        # Loading text placement
        mid = start + (end - start) * 0.52
        # Slight perpendicular offset for readability
        perp = np.array([-unit[1], unit[0]])
        text_pos = mid + perp * 0.14
        ax.text(text_pos[0], text_pos[1], f"{loading_val:.3f}",
                ha='center', va='center', fontsize=8.5, fontweight='normal', color=TEXT_COLOR, zorder=5)

    # --- CQ Indicators (Fan out above CQ) ---
    cq_items = [f'CQ{i}' for i in range(1, 7)]
    # Horizontal row across top: y = 10.5
    cq_x_coords = np.linspace(7.2, 13.2, 6)
    for idx, item in enumerate(cq_items):
        bx = cq_x_coords[idx]
        by = 10.55
        draw_indicator_box(bx, by, item)
        draw_measurement_arrow(pos_cq, np.array([bx, by]), loadings.get(item, 0.830))

    # --- CCCC Indicators (Column to the left of CCCC) ---
    cccc_items = [f'CCCC{i}' for i in range(1, 7)]
    cccc_y_coords = np.linspace(9.6, 6.2, 6)
    for idx, item in enumerate(cccc_items):
        bx = 1.6
        by = cccc_y_coords[idx]
        draw_indicator_box(bx, by, item)
        draw_measurement_arrow(pos_cccc, np.array([bx, by]), loadings.get(item, 0.825))

    # --- INC Indicators (Column to the left of INC) ---
    inc_items = [f'INC{i}' for i in range(1, 7)]
    inc_y_coords = np.linspace(4.6, 1.2, 6)
    for idx, item in enumerate(inc_items):
        bx = 1.6
        by = inc_y_coords[idx]
        draw_indicator_box(bx, by, item)
        draw_measurement_arrow(pos_inc, np.array([bx, by]), loadings.get(item, 0.835))

    # --- KTC Indicators (Horizontal row below KTC) ---
    ktc_items = [f'KTC{i}' for i in range(1, 7)]
    ktc_x_coords = np.linspace(7.2, 13.2, 6)
    for idx, item in enumerate(ktc_items):
        bx = ktc_x_coords[idx]
        by = -0.15
        draw_indicator_box(bx, by, item)
        draw_measurement_arrow(pos_ktc, np.array([bx, by]), loadings.get(item, 0.834))

    # --- TTP Indicators (Column to the right of TTP) ---
    ttp_items = [f'TTP{i}' for i in range(1, 7)]
    ttp_y_coords = np.linspace(7.0, 3.4, 6)
    for idx, item in enumerate(ttp_items):
        bx = 14.8
        by = ttp_y_coords[idx]
        draw_indicator_box(bx, by, item)
        draw_measurement_arrow(pos_ttp, np.array([bx, by]), loadings.get(item, 0.833))

    # 3. DRAW CONSTRUCT CIRCLES
    for c_name, center in construct_positions.items():
        circle = patches.Circle(center, R, facecolor=BLUE_CIRCLE, edgecolor="#1B4F72", linewidth=1.5, zorder=3)
        ax.add_patch(circle)
        
        # Endogenous circle gets R2 inside
        if c_name == 'TTP':
            ax.text(center[0], center[1], f"{r2_val:.3f}", ha='center', va='center',
                    fontsize=13, fontweight='bold', color='white', zorder=4)
            # Label below circle
            ax.text(center[0], center[1] - R - 0.28, construct_labels[c_name],
                    ha='center', va='top', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)
        else:
            # Exogenous circles: label placed below or appropriately
            if c_name == 'CQ':
                ax.text(center[0], center[1] - R - 0.25, construct_labels[c_name],
                        ha='center', va='top', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)
            elif c_name == 'KTC':
                ax.text(center[0], center[1] + R + 0.15, construct_labels[c_name],
                        ha='center', va='bottom', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)
            else:
                ax.text(center[0], center[1] - R - 0.25, construct_labels[c_name],
                        ha='center', va='top', fontsize=9.5, fontweight='bold', color=TEXT_COLOR, zorder=4)

    # 4. DRAW STRUCTURAL PATH ARROWS
    def draw_structural_arrow(source_center, target_center, beta_val):
        vec = target_center - source_center
        dist = np.linalg.norm(vec)
        unit = vec / dist
        start = source_center + unit * R
        end = target_center - unit * (R + 0.05)
        
        ax.annotate('', xy=(end[0], end[1]), xytext=(start[0], start[1]),
                    arrowprops=dict(arrowstyle="-|>", color=EDGE_COLOR, lw=1.5, mutation_scale=14), zorder=2)
        
        # Position beta text along arrow with slight perpendicular shift
        mid = start + (end - start) * 0.48
        perp = np.array([-unit[1], unit[0]])
        text_pos = mid + perp * 0.22
        ax.text(text_pos[0], text_pos[1], f"{beta_val:.3f}",
                ha='center', va='center', fontsize=10.5, fontweight='bold', color=TEXT_COLOR, zorder=5)

    # CQ -> TTP
    draw_structural_arrow(pos_cq, pos_ttp, path_coefs.get('CQ', 0.219))
    # CCCC -> TTP
    draw_structural_arrow(pos_cccc, pos_ttp, path_coefs.get('CCCC', 0.207))
    # INC -> TTP
    draw_structural_arrow(pos_inc, pos_ttp, path_coefs.get('INC', 0.309))
    # KTC -> TTP
    draw_structural_arrow(pos_ktc, pos_ttp, path_coefs.get('KTC', 0.298))

    fig.savefig(output_path, dpi=800, bbox_inches='tight', facecolor=bg_color)
    plt.close(fig)
    print(f"[SMARTPLS] Successfully generated SmartPLS diagram at: {output_path} (800 DPI)")


if __name__ == "__main__":
    from data_preprocessing import DataPreprocessor
    from pls_sem_analysis import PlsSemModel
    
    prep = DataPreprocessor().run_full_preprocessing_pipeline()
    pls = PlsSemModel(prep['cleaned_data']).fit_model()
    
    loadings = {k: pls.outer_loadings[k] for k in pls.outer_loadings}
    paths = pls.path_coefficients
    r2 = pls.r2
    
    # 1. Authentic SmartPLS Canvas (Gray background)
    draw_smartpls_diagram(loadings, paths, r2, "Results/Figures/fig12_structural_model.png", bg_color="#CBCBCB")
    draw_smartpls_diagram(loadings, paths, r2, "Results/Figures/fig12_smartpls_gray_canvas.png", bg_color="#CBCBCB")
    
    # 2. Clean Publication Canvas (White background)
    draw_smartpls_diagram(loadings, paths, r2, "Results/Figures/fig12_smartpls_white_canvas.png", bg_color="#FFFFFF")

