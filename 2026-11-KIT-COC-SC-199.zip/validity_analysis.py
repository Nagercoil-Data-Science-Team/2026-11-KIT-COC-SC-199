"""
Validity Analysis Module
Calculates Convergent Validity (AVE, Outer Loadings) and Discriminant Validity
(HTMT Ratio, Fornell–Larcker Criterion, Cross-Loadings).
"""

import numpy as np
import pandas as pd
from scipy import stats


CONSTRUCT_ITEMS = {
    'CQ': [f'CQ{i}' for i in range(1, 7)],
    'CCCC': [f'CCCC{i}' for i in range(1, 7)],
    'INC': [f'INC{i}' for i in range(1, 7)],
    'KTC': [f'KTC{i}' for i in range(1, 7)],
    'TTP': [f'TTP{i}' for i in range(1, 7)]
}

CONSTRUCT_NAMES = list(CONSTRUCT_ITEMS.keys())


def compute_ave(loadings):
    """Computes Average Variance Extracted: AVE = sum(lambda^2) / k"""
    loadings_arr = np.asarray(loadings)
    return float(np.mean(loadings_arr**2))


def compute_htmt_matrix(df):
    """
    Computes Heterotrait-Monotrait Ratio (HTMT) matrix across all construct pairs:
    HTMT_ij = mean(correlations between indicators of i and j) /
              sqrt(mean(correlations within i) * mean(correlations within j))
    """
    k_consts = len(CONSTRUCT_NAMES)
    htmt_matrix = pd.DataFrame(np.zeros((k_consts, k_consts)), index=CONSTRUCT_NAMES, columns=CONSTRUCT_NAMES)
    
    # Calculate within-construct average correlation (monotrait-heteromethod)
    within_corrs = {}
    for c in CONSTRUCT_NAMES:
        items = CONSTRUCT_ITEMS[c]
        corr_sub = df[items].corr().values
        # Take upper triangle excluding diagonal
        upper_tri = corr_sub[np.triu_indices(len(items), k=1)]
        within_corrs[c] = np.mean(upper_tri)

    # Calculate between-construct average correlation and HTMT
    for i in range(k_consts):
        c_i = CONSTRUCT_NAMES[i]
        for j in range(k_consts):
            c_j = CONSTRUCT_NAMES[j]
            if i == j:
                htmt_matrix.loc[c_i, c_j] = 1.000
            elif i > j:
                items_i = CONSTRUCT_ITEMS[c_i]
                items_j = CONSTRUCT_ITEMS[c_j]
                
                # Between-correlations
                corr_sub = df[items_i].corrwith(df[items_j], axis=0) # wait, cross correlations:
                cross_corr = df[items_i + items_j].corr().loc[items_i, items_j].values
                mean_between = np.mean(cross_corr)
                
                denom = np.sqrt(within_corrs[c_i] * within_corrs[c_j])
                if denom > 1e-9:
                    htmt_val = mean_between / denom
                else:
                    htmt_val = 0.0
                    
                htmt_matrix.loc[c_i, c_j] = round(float(htmt_val), 4)
                htmt_matrix.loc[c_j, c_i] = round(float(htmt_val), 4)

    return htmt_matrix


def compute_fornell_larcker_matrix(df, ave_dict, latent_scores=None):
    """
    Computes Fornell-Larcker Criterion Matrix:
    Diagonal = Square root of AVE (sqrt(AVE))
    Off-diagonal = Inter-construct correlations
    """
    k_consts = len(CONSTRUCT_NAMES)
    fl_matrix = pd.DataFrame(np.zeros((k_consts, k_consts)), index=CONSTRUCT_NAMES, columns=CONSTRUCT_NAMES)
    
    # Inter-construct correlations from latent scores or composite sums
    if latent_scores is not None and all(c in latent_scores.columns for c in CONSTRUCT_NAMES):
        corr_matrix = latent_scores[CONSTRUCT_NAMES].corr()
    else:
        # Composite score correlation
        comp_df = pd.DataFrame({c: df[CONSTRUCT_ITEMS[c]].mean(axis=1) for c in CONSTRUCT_NAMES})
        corr_matrix = comp_df.corr()

    for i, c_i in enumerate(CONSTRUCT_NAMES):
        for j, c_j in enumerate(CONSTRUCT_NAMES):
            if i == j:
                sqrt_ave = np.sqrt(ave_dict[c_i])
                fl_matrix.loc[c_i, c_j] = round(float(sqrt_ave), 4)
            else:
                fl_matrix.loc[c_i, c_j] = round(float(corr_matrix.loc[c_i, c_j]), 4)

    return fl_matrix


def compute_cross_loadings(df, latent_scores=None):
    """
    Computes Cross-Loadings matrix: correlation of each indicator with each latent construct score.
    """
    if latent_scores is None:
        latent_scores = pd.DataFrame({c: df[CONSTRUCT_ITEMS[c]].mean(axis=1) for c in CONSTRUCT_NAMES})
        
    all_items = [item for items in CONSTRUCT_ITEMS.values() for item in items]
    cross_loadings = pd.DataFrame(index=all_items, columns=CONSTRUCT_NAMES)
    
    for item in all_items:
        for c in CONSTRUCT_NAMES:
            corr, _ = stats.pearsonr(df[item], latent_scores[c])
            cross_loadings.loc[item, c] = round(float(corr), 4)
            
    return cross_loadings


def run_validity_analysis(df, outer_loadings_df, latent_scores=None):
    """
    Executes complete convergent and discriminant validity assessment.
    
    Returns:
    - ave_df: Average Variance Extracted per construct and threshold evaluation
    - outer_loadings_full: Detailed outer loadings table
    - htmt_df: HTMT matrix with threshold assessment
    - fornell_larcker_df: Fornell-Larcker matrix
    - cross_loadings_df: Cross-loadings matrix
    """
    # 1. Compute AVE per construct
    ave_dict = {}
    ave_rows = []
    
    for construct in CONSTRUCT_NAMES:
        c_loadings = outer_loadings_df[outer_loadings_df['Construct'] == construct]['Outer_Loading'].values
        ave_val = compute_ave(c_loadings)
        ave_dict[construct] = ave_val
        
        ave_eval = "Established (>= 0.50)" if ave_val >= 0.50 else "Sub-threshold (< 0.50)"
        ave_rows.append({
            "Construct": construct,
            "AVE": round(ave_val, 4),
            "Threshold": ">= 0.50",
            "Convergent_Validity_Assessment": ave_eval
        })
    ave_df = pd.DataFrame(ave_rows)

    # 2. HTMT Matrix
    htmt_df = compute_htmt_matrix(df)
    
    # 3. Fornell-Larcker Matrix
    fornell_larcker_df = compute_fornell_larcker_matrix(df, ave_dict, latent_scores)

    # 4. Cross Loadings
    cross_loadings_df = compute_cross_loadings(df, latent_scores)

    return {
        "ave_df": ave_df,
        "outer_loadings_df": outer_loadings_df,
        "htmt_df": htmt_df,
        "fornell_larcker_df": fornell_larcker_df,
        "cross_loadings_df": cross_loadings_df
    }


if __name__ == "__main__":
    from data_preprocessing import DataPreprocessor
    from reliability_analysis import run_reliability_analysis
    
    prep = DataPreprocessor()
    res = prep.run_full_preprocessing_pipeline()
    c_rel, i_rel = run_reliability_analysis(res['cleaned_data'])
    val_res = run_validity_analysis(res['cleaned_data'], i_rel)
    print("AVE Summary:\n", val_res['ave_df'])
    print("\nHTMT Matrix:\n", val_res['htmt_df'])
    print("\nFornell-Larcker Criterion:\n", val_res['fornell_larcker_df'])

