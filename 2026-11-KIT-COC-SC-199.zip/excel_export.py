"""
Excel Export Module
Constructs the comprehensive 20-sheet publication-grade Excel workbook
'Technology_Transfer_Research_Results.xlsx' using openpyxl with executive styling.
"""

import os
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
import pandas as pd


# Executive Academic Palette
HEADER_FILL = PatternFill(start_color="1B365D", end_color="1B365D", fill_type="solid")
HEADER_FONT = Font(name="Times New Roman", size=11, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="Times New Roman", size=14, bold=True, color="1B365D")
SUBTITLE_FONT = Font(name="Times New Roman", size=10, italic=True, color="555555")
REGULAR_FONT = Font(name="Times New Roman", size=10)
BOLD_FONT = Font(name="Times New Roman", size=10, bold=True)

THIN_SIDE = Side(border_style="thin", color="D3D3D3")
CELL_BORDER = Border(left=THIN_SIDE, right=THIN_SIDE, top=THIN_SIDE, bottom=THIN_SIDE)


def style_worksheet(ws, title_text):
    """Applies title block, auto-fits column widths, and styles headers."""
    # Insert Title Block
    ws.insert_rows(1, amount=3)
    ws.cell(row=1, column=1, value=title_text).font = TITLE_FONT
    ws.cell(row=2, column=1, value="Research Project: Academic Returnees in University–Industry Collaboration | Mixed-Methods PLS-SEM Analysis").font = SUBTITLE_FONT
    
    header_row = 4
    # Style Table Header
    for col_idx in range(1, ws.max_column + 1):
        cell = ws.cell(row=header_row, column=col_idx)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        
    # Style Data Rows
    for row_idx in range(header_row + 1, ws.max_row + 1):
        for col_idx in range(1, ws.max_column + 1):
            cell = ws.cell(row=row_idx, column=col_idx)
            cell.font = REGULAR_FONT
            cell.border = CELL_BORDER
            
            # Numeric alignment and formatting
            if isinstance(cell.value, (int, float)):
                if isinstance(cell.value, float):
                    cell.number_format = "0.0000"
                cell.alignment = Alignment(horizontal="right", vertical="center")
            else:
                cell.alignment = Alignment(horizontal="left", vertical="center")

    # Auto-adjust column widths
    for col in ws.columns:
        max_len = 0
        col_letter = get_column_letter(col[0].column)
        for cell in col:
            # Skip title row from width measurement
            if cell.row < header_row:
                continue
            val_str = str(cell.value or "")
            if len(val_str) > max_len:
                max_len = len(val_str)
        ws.column_dimensions[col_letter].width = max(max_len + 4, 12)


def export_full_research_workbook(data_package, output_path="Results/Excel_Tables/Technology_Transfer_Research_Results.xlsx"):
    """
    Creates and populates the 20 required sheets in the Excel workbook.
    """
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    wb = openpyxl.Workbook()
    # Remove default sheet
    wb.remove(wb.active)

    # 1. Demographic_Characteristics
    ws1 = wb.create_sheet("Demographic_Characteristics")
    demo_list = []
    for var_name, d_df in data_package['demographics'].items():
        for _, r in d_df.iterrows():
            demo_list.append({
                "Demographic_Variable": var_name,
                "Category": r['Category'],
                "Frequency_N": r['Frequency'],
                "Percentage_%": r['Percentage']
            })
    _write_df_to_sheet(ws1, pd.DataFrame(demo_list))
    style_worksheet(ws1, "Demographic Characteristics of Academic Returnees (N = 450)")

    # 2. Descriptive_Statistics
    ws2 = wb.create_sheet("Descriptive_Statistics")
    _write_df_to_sheet(ws2, data_package['descriptive_stats'])
    style_worksheet(ws2, "Descriptive Statistics: Measurement Items and Construct Composites")

    # 3. Measurement_Items
    ws3 = wb.create_sheet("Measurement_Items")
    items_meta = _get_measurement_items_metadata()
    _write_df_to_sheet(ws3, items_meta)
    style_worksheet(ws3, "Measurement Items and Operational Definitions of Research Constructs")

    # 4. Cronbach_Alpha
    ws4 = wb.create_sheet("Cronbach_Alpha")
    _write_df_to_sheet(ws4, data_package['construct_reliability'][['Construct', 'Number_of_Items', 'Cronbach_Alpha', 'Alpha_Evaluation']])
    style_worksheet(ws4, "Cronbach's Alpha Internal Consistency Assessment (Target: 0.75–0.85)")

    # 5. Composite_Reliability
    ws5 = wb.create_sheet("Composite_Reliability")
    _write_df_to_sheet(ws5, data_package['construct_reliability'][['Construct', 'Composite_Reliability', 'rho_A', 'CR_Evaluation', 'rho_A_Evaluation']])
    style_worksheet(ws5, "Composite Reliability (CR) and Dijkstra-Henseler's rho_A")

    # 6. Convergent_Validity
    ws6 = wb.create_sheet("Convergent_Validity")
    _write_df_to_sheet(ws6, data_package['ave_df'])
    style_worksheet(ws6, "Convergent Validity: Average Variance Extracted (AVE >= 0.50)")

    # 7. HTMT_Analysis
    ws7 = wb.create_sheet("HTMT_Analysis")
    _write_df_to_sheet(ws7, data_package['htmt_df'].reset_index().rename(columns={'index': 'Construct'}))
    style_worksheet(ws7, "Heterotrait-Monotrait Ratio (HTMT) Discriminant Validity Matrix (< 0.85)")

    # 8. Fornell_Larcker
    ws8 = wb.create_sheet("Fornell_Larcker")
    _write_df_to_sheet(ws8, data_package['fornell_larcker_df'].reset_index().rename(columns={'index': 'Construct'}))
    style_worksheet(ws8, "Fornell–Larcker Criterion Assessment Matrix (Diagonal = Sqrt(AVE))")

    # 9. VIF_Analysis
    ws9 = wb.create_sheet("VIF_Analysis")
    _write_df_to_sheet(ws9, data_package['vif_df'])
    style_worksheet(ws9, "Collinearity Assessment: Inner VIF and Tolerance Values (< 3.3 / 5.0)")

    # 10. Path_Coefficients
    ws10 = wb.create_sheet("Path_Coefficients")
    _write_df_to_sheet(ws10, data_package['path_df'])
    style_worksheet(ws10, "PLS-SEM Structural Path Coefficients (Direct Effects on TTP)")

    # 11. Hypothesis_Testing
    ws11 = wb.create_sheet("Hypothesis_Testing")
    _write_df_to_sheet(ws11, data_package['hypothesis_df'])
    style_worksheet(ws11, "Hypothesis Testing Results (H1–H4, 5,000 Bootstrap Resamples, Alpha = 0.05)")

    # 12. R2_Adjusted_R2
    ws12 = wb.create_sheet("R2_Adjusted_R2")
    _write_df_to_sheet(ws12, data_package['r2_df'])
    style_worksheet(ws12, "Coefficient of Determination (R²) and Adjusted R² for Technology Transfer Performance")

    # 13. Effect_Size_f2
    ws13 = wb.create_sheet("Effect_Size_f2")
    _write_df_to_sheet(ws13, data_package['f2_df'])
    style_worksheet(ws13, "Predictor Effect Sizes (f²) on Technology Transfer Performance")

    # 14. Predictive_Relevance_Q2
    ws14 = wb.create_sheet("Predictive_Relevance_Q2")
    _write_df_to_sheet(ws14, data_package['q2_df'])
    style_worksheet(ws14, "Predictive Relevance (Q²) via Blindfolding (Omission Distance d = 7)")

    # 15. Bootstrapping_Results
    ws15 = wb.create_sheet("Bootstrapping_Results")
    _write_df_to_sheet(ws15, data_package['bootstrapping_df'])
    style_worksheet(ws15, "Full Bootstrapping Parameter Estimates (5,000 Iterations, 95% CIs)")

    # 16. Qualitative_Themes
    ws16 = wb.create_sheet("Qualitative_Themes")
    _write_df_to_sheet(ws16, data_package['theme_frequency_df'])
    style_worksheet(ws16, "Qualitative Thematic Analysis: Core Themes and Frequency Distribution (N = 20)")

    # 17. Mixed_Methods_Integration
    ws17 = wb.create_sheet("Mixed_Methods_Integration")
    _write_df_to_sheet(ws17, data_package['joint_display_df'])
    style_worksheet(ws17, "Joint Display Table: Explanatory Sequential Integration of Quant and Qual Findings")

    # 18. Software_Hardware
    ws18 = wb.create_sheet("Software_Hardware")
    _write_df_to_sheet(ws18, data_package['software_hardware_df'])
    style_worksheet(ws18, "Empirical Execution Environment: Hardware and Software Specifications")

    # 19. Hyperparameters
    ws19 = wb.create_sheet("Hyperparameters")
    _write_df_to_sheet(ws19, data_package['hyperparameters_df'])
    style_worksheet(ws19, "Hyperparameter Documentation: PLS-SEM Algorithm and Bootstrapping Settings")

    # 20. Data_Preprocessing_Log
    ws20 = wb.create_sheet("Data_Preprocessing_Log")
    log_df = pd.DataFrame({"Step_Index": range(1, len(data_package['log_entries']) + 1), "Preprocessing_Event": data_package['log_entries']})
    _write_df_to_sheet(ws20, log_df)
    style_worksheet(ws20, "Data Preprocessing and Data Screening Audit Log")

    wb.save(output_path)
    print(f"[EXCEL] 20-sheet research workbook successfully exported to: {output_path}")


def _write_df_to_sheet(ws, df):
    """Writes a DataFrame to an openpyxl worksheet starting at row 1."""
    # Write header
    for c_idx, col_name in enumerate(df.columns, start=1):
        ws.cell(row=1, column=c_idx, value=str(col_name))
        
    # Write data
    for r_idx, row in enumerate(df.itertuples(index=False), start=2):
        for c_idx, val in enumerate(row, start=1):
            ws.cell(row=r_idx, column=c_idx, value=val)


def _get_measurement_items_metadata():
    """Returns the operational definitions of all 30 measurement items from workflow document."""
    items_data = [
        # CQ
        ("CQ1", "Cultural Intelligence", "I can effectively adapt my behaviour when interacting with individuals from different cultural backgrounds."),
        ("CQ2", "Cultural Intelligence", "I understand how cultural differences influence professional relationships between universities and industries."),
        ("CQ3", "Cultural Intelligence", "I can adjust my working approaches to accommodate different cultural expectations."),
        ("CQ4", "Cultural Intelligence", "I can recognize cultural differences in academic and industrial working environments."),
        ("CQ5", "Cultural Intelligence", "I can effectively manage misunderstandings arising from cultural differences during collaborative activities."),
        ("CQ6", "Cultural Intelligence", "My cross-cultural experiences help me establish effective relationships with university and industry partners."),
        # CCCC
        ("CCCC1", "Cross-Cultural Communication Competence", "I can communicate research-related information effectively with industry partners from different cultural backgrounds."),
        ("CCCC2", "Cross-Cultural Communication Competence", "I can adjust my communication style according to the cultural backgrounds of collaboration partners."),
        ("CCCC3", "Cross-Cultural Communication Competence", "I can clearly explain complex academic concepts to industry professionals."),
        ("CCCC4", "Cross-Cultural Communication Competence", "I can effectively manage communication challenges during cross-cultural collaborative activities."),
        ("CCCC5", "Cross-Cultural Communication Competence", "I actively encourage knowledge exchange between academic researchers and industrial professionals."),
        ("CCCC6", "Cross-Cultural Communication Competence", "I can establish mutual understanding between university researchers and industry partners."),
        # INC
        ("INC1", "International Networking Capability", "I maintain professional relationships with international academic researchers."),
        ("INC2", "International Networking Capability", "I maintain professional connections with international industry professionals."),
        ("INC3", "International Networking Capability", "I use my international networks to identify potential university–industry collaboration opportunities."),
        ("INC4", "International Networking Capability", "I can connect Chinese university researchers with relevant international research partners."),
        ("INC5", "International Networking Capability", "I use my professional networks to facilitate access to research knowledge and technological resources."),
        ("INC6", "International Networking Capability", "My international professional relationships support the development of university–industry collaborative projects."),
        # KTC
        ("KTC1", "Knowledge Translation Capability", "I can translate academic research findings into knowledge that is useful for industrial applications."),
        ("KTC2", "Knowledge Translation Capability", "I can identify industrial problems that can be addressed through academic research."),
        ("KTC3", "Knowledge Translation Capability", "I can adapt research outputs to meet the technological requirements of industry partners."),
        ("KTC4", "Knowledge Translation Capability", "I can communicate the practical value of academic innovations to industrial stakeholders."),
        ("KTC5", "Knowledge Translation Capability", "I can facilitate the application of research-based knowledge in industrial settings."),
        ("KTC6", "Knowledge Translation Capability", "I can help bridge the gap between theoretical research and practical industrial requirements."),
        # TTP
        ("TTP1", "Technology Transfer Performance", "Our university–industry collaborations successfully transfer academic knowledge to industrial partners."),
        ("TTP2", "Technology Transfer Performance", "Research findings generated through our collaborations are effectively applied in industrial settings."),
        ("TTP3", "Technology Transfer Performance", "Our collaborative projects contribute to the adoption of new technologies by industry partners."),
        ("TTP4", "Technology Transfer Performance", "Our university–industry collaborations generate practical technological innovations."),
        ("TTP5", "Technology Transfer Performance", "Our collaborative activities contribute to the development of commercially applicable technologies."),
        ("TTP6", "Technology Transfer Performance", "Our university–industry collaborations achieve their intended technology transfer objectives.")
    ]
    return pd.DataFrame(items_data, columns=["Item_Code", "Construct_Name", "Questionnaire_Measurement_Statement"])
