# How Do Cross-Cultural Boundary Spanners Drive Technology Transfer? Role Matching and Action Pathways of Academic Returnees in University–Industry Collaboration

**Explanatory Sequential Mixed-Methods Research Implementation**  
**PLS-SEM & Thematic Analysis Computational Framework**

---

## 1. Project Overview and Research Framework

This repository provides a complete, reproducible, publication-grade Python computational framework for investigating how academic returnees in China function as cross-cultural boundary spanners to catalyze university–industry technology transfer.

The empirical model evaluates four primary cross-cultural capabilities:
1. **Cultural Intelligence (CQ)** (6 items: `CQ1`–`CQ6`)
2. **Cross-Cultural Communication Competence (CCCC)** (6 items: `CCCC1`–`CCCC6`)
3. **International Networking Capability (INC)** (6 items: `INC1`–`INC6`)
4. **Knowledge Translation Capability (KTC)** (6 items: `KTC1`–`KTC6`)

predicting the focal outcome:
- **Technology Transfer Performance (TTP)** (6 items: `TTP1`–`TTP6`)

### Structural Equation
$$\text{TTP} = \beta_1(\text{CQ}) + \beta_2(\text{CCCC}) + \beta_3(\text{INC}) + \beta_4(\text{KTC}) + \varepsilon$$

### Core Research Hypotheses
- **H1**: Cultural intelligence positively influences technology transfer performance in university–industry collaboration.
- **H2**: Cross-Cultural communication competence positively influences technology transfer performance in university–industry collaboration.
- **H3**: International networking capability positively influences technology transfer performance in university–industry collaboration.
- **H4**: Knowledge translation capability positively influences technology transfer performance in university–industry collaboration.

---

## 2. Directory Structure and Deliverables

```
2026-11-KIT-COC-SC-199/
│
├── main.py                          # Master orchestrator CLI script
├── data_preprocessing.py            # Preprocessing, screening, CMB & audit logging
├── reliability_analysis.py          # Cronbach's Alpha, CR, rho_A, CITC
├── validity_analysis.py             # Convergent (AVE) & Discriminant (HTMT, Fornell-Larcker)
├── pls_sem_analysis.py              # PLS-SEM structural modeling, R2, f2, Q2, VIF
├── hypothesis_testing.py            # 5,000 bootstrap resamplings & decision rules
├── qualitative_analysis.py          # 8-stage thematic analysis workflow
├── mixed_methods_integration.py     # Joint displays & role-matching action pathways
├── visualization.py                 # 18 publication-quality figures (800 DPI, Times New Roman)
├── excel_export.py                  # 20-sheet formatted Excel workbook builder
├── data_generator.py                # Baseline template verification data generator
├── requirements.txt                 # Exact package version specifications
├── README.md                        # Research documentation and execution guide
│
├── data/
│   ├── questionnaire_data.csv       # Survey dataset (N=450 respondents)
│   ├── questionnaire_data.xlsx      # Excel format of questionnaire dataset
│   ├── interview_transcripts.csv    # Qualitative transcripts (N=20 participants)
│   ├── README_DATA_REQUIREMENTS.md  # Detailed field data replacement guide
│   └── interview_transcripts/       # Individual text transcript files
│
├── Results/
│   ├── Figures/                     # All 18 publication-quality figures at 800 DPI
│   │   ├── fig01_demographic_distribution.png
│   │   ├── fig02_gender_distribution.png
│   │   ├── fig03_age_group_distribution.png
│   │   ├── fig04_construct_mean_scores.png
│   │   ├── fig05_cronbach_alpha_comparison.png
│   │   ├── fig06_composite_reliability_comparison.png
│   │   ├── fig07_ave_comparison.png
│   │   ├── fig08_outer_loadings.png
│   │   ├── fig09_htmt_heatmap.png
│   │   ├── fig10_fornell_larcker_assessment.png
│   │   ├── fig11_vif_comparison.png
│   │   ├── fig12_structural_model.png
│   │   ├── fig13_path_coefficients.png
│   │   ├── fig14_r2_adjusted_r2.png
│   │   ├── fig15_effect_size_f2.png
│   │   ├── fig16_bootstrapped_ci.png
│   │   ├── fig17_qualitative_theme_frequencies.png
│   │   └── fig18_mixed_methods_integration.png
│   │
│   ├── Excel_Tables/
│   │   └── Technology_Transfer_Research_Results.xlsx  # 20 formatted sheets
│   │
│   ├── Statistical_Reports/
│   │   ├── empirical_statistical_report.md
│   │   └── mixed_methods_integration_report.md
│   │
│   ├── Qualitative_Results/
│   │   └── qualitative_thematic_report.md
│   │
│   └── Logs/
│       └── data_preprocessing_log.txt
│
└── Technology_Transfer_Research_Results.xlsx  # Mirrored root copy for direct access
```

---

## 3. The 20 Required Excel Output Sheets

The output workbook `Technology_Transfer_Research_Results.xlsx` contains exactly 20 professionally formatted sheets:

1. `Demographic_Characteristics`: Frequencies and percentages for Gender, Age, Education, Position, and Institution.
2. `Descriptive_Statistics`: Mean, SD, Median, Min, Max, Skewness, and Kurtosis for all 30 indicators and 5 constructs.
3. `Measurement_Items`: Operational definitions and questionnaire statements for all 30 indicators.
4. `Cronbach_Alpha`: Internal consistency reliability and methodological evaluations.
5. `Composite_Reliability`: Composite Reliability (CR) and Dijkstra-Henseler's $\rho_A$.
6. `Convergent_Validity`: Average Variance Extracted (AVE $\ge 0.50$) assessments.
7. `HTMT_Analysis`: Heterotrait-Monotrait Ratio matrix ($< 0.85$).
8. `Fornell_Larcker`: Discriminant validity assessment ($\sqrt{\text{AVE}} > r_{ij}$).
9. `VIF_Analysis`: Inner VIF and Tolerance values ($< 3.3 / 5.0$).
10. `Path_Coefficients`: Direct structural path coefficients ($\beta$).
11. `Hypothesis_Testing`: Hypotheses H1–H4 results with 5,000 bootstrap resamples and p-values.
12. `R2_Adjusted_R2`: Coefficient of determination ($R^2$), Adjusted $R^2$, RMSE, and MAE.
13. `Effect_Size_f2`: Cohen's $f^2$ effect sizes (Small, Medium, Large).
14. `Predictive_Relevance_Q2`: Stone-Geisser $Q^2$ cross-validated blindfolding ($d = 7$).
15. `Bootstrapping_Results`: Complete sampling distributions, SEs, and 95% percentile CIs.
16. `Qualitative_Themes`: Coded qualitative themes, subthemes, and frequency rankings ($N = 20$).
17. `Mixed_Methods_Integration`: Explanatory sequential joint display table linking quant and qual evidence.
18. `Software_Hardware`: Actual system hardware (CPU, RAM, GPU) and software environment versions.
19. `Hyperparameters`: Documentation of all PLS-SEM and bootstrap configuration parameters.
20. `Data_Preprocessing_Log`: Complete audit trail of missing data treatments, screening, and CMB tests.

---

## 4. Mandatory Publication Plotting Configuration (Section 15)

Every figure strictly conforms to the requested matplotlib specification:
- **Resolution**: 800 DPI (`dpi=800`)
- **Dimensions**: $11 \times 7$ inches (`figsize=(11, 7)`)
- **Typography**: Times New Roman, bold axis labels (`axes.labelweight = 'bold'`), bold titles (`axes.titleweight = 'bold'`)
- **Gridlines**: Completely removed (`axes.grid = False`, `grid.alpha = 0`)
- **Bounding Box**: Tight padding (`bbox_inches='tight'`)
- **Format**: High-resolution PNG

---

## 5. Installation and Execution

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Run Full Research Pipeline
```bash
python main.py --n-boot 5000 --seed 42
```

### Step 3: Run with Custom Empirical Dataset
When you have collected your actual field survey dataset from Chinese universities and institutions:
```bash
python main.py --data-file path/to/your_collected_questionnaire.csv --interview-file path/to/your_interview_transcripts.csv --n-boot 5000
```

---

## 6. Methodological and Data Integrity Standards

1. **No Data Fabrication**: The pipeline never hardcodes statistical numbers. All outputs (Alphas, CRs, AVEs, path coefficients, t-statistics, p-values, R², f², Q²) are computed dynamically.
2. **Empirical Status Transparency**: If the pipeline runs on template verification data prior to the user's field upload, it explicitly records the verification status in the logs, reports, and Excel sheets.
3. **Reproducibility**: All random sampling procedures utilize fixed seeds (default `seed = 42`) ensuring bitwise identical bootstrap replications across multiple runs.

