"""
PLS-SEM Structural Model Analysis Module
Executes Partial Least Squares Structural Equation Modeling (PLS-SEM),
extracts latent variable scores, estimates path coefficients, computes R2, Adjusted R2,
f2 effect sizes, Stone-Geisser Q2 predictive relevance (blindfolding), PLSpredict errors,
and collinearity (Inner VIF, Outer VIF, Tolerance).
"""

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm
from sklearn.metrics import mean_squared_error, mean_absolute_error

from plspm.config import Config, Structure, MV
from plspm.mode import Mode
from plspm.scheme import Scheme
from plspm.plspm import Plspm


CONSTRUCT_ITEMS = {
    'CQ': [f'CQ{i}' for i in range(1, 7)],
    'CCCC': [f'CCCC{i}' for i in range(1, 7)],
    'INC': [f'INC{i}' for i in range(1, 7)],
    'KTC': [f'KTC{i}' for i in range(1, 7)],
    'TTP': [f'TTP{i}' for i in range(1, 7)]
}

IV_NAMES = ['CQ', 'CCCC', 'INC', 'KTC']
DV_NAME = 'TTP'
ALL_CONSTRUCTS = ['CQ', 'CCCC', 'INC', 'KTC', 'TTP']


class PlsSemModel:
    def __init__(self, data_df):
        self.data_df = data_df
        self.plspm_model = None
        self.latent_scores = None
        self.outer_loadings = None
        self.outer_weights = None
        self.path_coefficients = None
        self.r2 = 0.0
        self.adj_r2 = 0.0
        self.f2_dict = {}
        self.q2_dict = {}
        self.vif_df = None
        self.outer_vif_df = None

    def fit_model(self, scheme_type="PATH"):
        """Configure and estimate the PLS-SEM model using plspm."""
        # 1. Inner Structure
        structure = Structure()
        structure.add_path(IV_NAMES, [DV_NAME])
        
        # 2. Config & Measurement Blocks (Mode A - Reflective)
        config = Config(structure.path(), scaled=True)
        for lv in ALL_CONSTRUCTS:
            mvs = [MV(item) for item in CONSTRUCT_ITEMS[lv]]
            config.add_lv(lv, Mode.A, *mvs)

        # 3. Model Estimation
        scheme = Scheme.PATH if scheme_type.upper() == "PATH" else Scheme.FACTORIAL
        try:
            self.plspm_model = Plspm(self.data_df, config, scheme=scheme, iterations=100, tolerance=1e-06)
        except Exception as e:
            # Fallback to FACTORIAL if PATH encounters singular resample matrix
            print(f"[PLS-SEM] PATH scheme warning: {e}. Switching to FACTORIAL scheme.")
            self.plspm_model = Plspm(self.data_df, config, scheme=Scheme.FACTORIAL, iterations=100, tolerance=1e-06)

        # 4. Extract Latent Variable Scores
        self.latent_scores = self.plspm_model.scores()
        
        # 5. Extract Outer Loadings & Weights
        outer_df = self.plspm_model.outer_model()
        self.outer_loadings = outer_df['loading'].to_dict()
        self.outer_weights = outer_df['weight'].to_dict()
        
        # 6. Extract Structural Path Coefficients
        paths_matrix = self.plspm_model.path_coefficients()
        self.path_coefficients = {iv: float(paths_matrix.loc[DV_NAME, iv]) for iv in IV_NAMES}

        # 7. Calculate R2 and Adjusted R2 for TTP
        n = len(self.data_df)
        k = len(IV_NAMES)
        
        # Regress TTP scores on IV scores
        X = self.latent_scores[IV_NAMES]
        y = self.latent_scores[DV_NAME]
        
        ols_model = sm.OLS(y, X).fit()
        self.r2 = float(ols_model.rsquared)
        self.adj_r2 = float(1.0 - (1.0 - self.r2) * ((n - 1) / (n - k - 1)))
        
        # 8. Compute f2 effect size for each predictor
        self.compute_effect_sizes(X, y)
        
        # 9. Compute Predictive Relevance Q2 via blindfolding
        self.compute_predictive_relevance()
        
        # 10. Compute Multicollinearity (VIF)
        self.compute_multicollinearity(X)

        return self

    def compute_effect_sizes(self, X, y):
        """
        Computes f2 effect size for each IV:
        f2 = (R2_included - R2_excluded) / (1 - R2_included)
        """
        r2_full = self.r2
        f2_results = []
        
        for iv in IV_NAMES:
            remaining_ivs = [x for x in IV_NAMES if x != iv]
            X_sub = X[remaining_ivs]
            ols_sub = sm.OLS(y, X_sub).fit()
            r2_excl = float(ols_sub.rsquared)
            
            denom = 1.0 - r2_full
            f2 = (r2_full - r2_excl) / denom if denom > 1e-9 else 0.0
            
            eval_str = "Large (>= 0.35)" if f2 >= 0.35 else ("Medium (0.15–0.35)" if f2 >= 0.15 else ("Small (0.02–0.15)" if f2 >= 0.02 else "Negligible (< 0.02)"))
            
            f2_results.append({
                "Predictor": iv,
                "R2_Included": round(r2_full, 4),
                "R2_Excluded": round(r2_excl, 4),
                "f2_Effect_Size": round(f2, 4),
                "Magnitude_Evaluation": eval_str
            })
            self.f2_dict[iv] = f2
            
        self.f2_df = pd.DataFrame(f2_results)

    def compute_predictive_relevance(self, omission_distance=7):
        """
        Computes Stone-Geisser Q2 predictive relevance using blindfolding procedure.
        Omission distance d = 7.
        Q2 = 1 - (SSE / SSO)
        """
        ttp_items = CONSTRUCT_ITEMS[DV_NAME]
        Y_dv = self.data_df[ttp_items].values.astype(float)
        N, P = Y_dv.shape
        
        # Compute blindfolding predictions
        sse = 0.0
        sso = 0.0
        mean_y = np.mean(Y_dv, axis=0)
        
        for p in range(P):
            actual = Y_dv[:, p]
            # Baseline total sum of squares
            sso += np.sum((actual - mean_y[p])**2)
            
            # Predict each case omitted at distance d
            pred = np.zeros(N)
            for d in range(omission_distance):
                test_idx = np.arange(d, N, omission_distance)
                train_idx = np.setdiff1d(np.arange(N), test_idx)
                
                # Fit linear regression on latent scores
                X_train = self.latent_scores[IV_NAMES].iloc[train_idx]
                y_train = actual[train_idx]
                X_test = self.latent_scores[IV_NAMES].iloc[test_idx]
                
                reg = sm.OLS(y_train, sm.add_constant(X_train)).fit()
                pred[test_idx] = reg.predict(sm.add_constant(X_test))
                
            sse += np.sum((actual - pred)**2)

        q2_val = 1.0 - (sse / sso) if sso > 1e-9 else 0.0
        q2_eval = "Substantial (Q2 > 0.50)" if q2_val > 0.50 else ("Medium (0.25 < Q2 <= 0.50)" if q2_val > 0.25 else ("Small (0 < Q2 <= 0.25)" if q2_val > 0.0 else "None (Q2 <= 0)"))
        
        self.q2_df = pd.DataFrame([{
            "Construct": DV_NAME,
            "SSO (Sum of Squared Observations)": round(sso, 2),
            "SSE (Sum of Squared Errors)": round(sse, 2),
            "Q2_Predictive_Relevance": round(q2_val, 4),
            "Threshold": "Q2 > 0.00",
            "Predictive_Relevance_Assessment": q2_eval
        }])
        self.q2_dict[DV_NAME] = q2_val

        # Prediction errors
        y_true = self.latent_scores[DV_NAME]
        X = self.latent_scores[IV_NAMES]
        ols = sm.OLS(y_true, X).fit()
        y_pred = ols.predict(X)
        self.rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
        self.mae = float(mean_absolute_error(y_true, y_pred))

    def compute_multicollinearity(self, X):
        """
        Computes Inner VIF for structural predictors and Outer VIF for measurement items:
        VIF_j = 1 / (1 - R2_j), Tolerance = 1 / VIF_j.
        """
        # 1. Inner VIF
        inner_vif_rows = []
        for iv in IV_NAMES:
            remaining = [x for x in IV_NAMES if x != iv]
            ols_iv = sm.OLS(X[iv], X[remaining]).fit()
            r2_iv = float(ols_iv.rsquared)
            vif = 1.0 / (1.0 - r2_iv) if (1.0 - r2_iv) > 1e-9 else 999.0
            tol = 1.0 / vif
            
            eval_str = "Ideal (VIF < 3.0)" if vif < 3.0 else ("Acceptable (VIF < 5.0)" if vif < 5.0 else "High Collinearity (VIF >= 5.0)")
            
            inner_vif_rows.append({
                "Variable_Type": "Inner Model (IV)",
                "Construct": iv,
                "Tolerance": round(tol, 4),
                "VIF": round(vif, 4),
                "Threshold": "VIF < 3.3 / 5.0",
                "Collinearity_Status": eval_str
            })
        self.vif_df = pd.DataFrame(inner_vif_rows)

        # 2. Outer VIF for items within each construct
        outer_vif_rows = []
        for construct, items in CONSTRUCT_ITEMS.items():
            sub_df = self.data_df[items]
            for item in items:
                other_items = [it for it in items if it != item]
                ols_item = sm.OLS(sub_df[item], sm.add_constant(sub_df[other_items])).fit()
                r2_it = float(ols_item.rsquared)
                vif_it = 1.0 / (1.0 - r2_it) if (1.0 - r2_it) > 1e-9 else 999.0
                tol_it = 1.0 / vif_it
                
                eval_str = "Ideal (VIF < 3.0)" if vif_it < 3.0 else ("Acceptable (VIF < 5.0)" if vif_it < 5.0 else "High Collinearity (VIF >= 5.0)")
                
                outer_vif_rows.append({
                    "Construct": construct,
                    "Indicator": item,
                    "Tolerance": round(tol_it, 4),
                    "VIF": round(vif_it, 4),
                    "Status": eval_str
                })
        self.outer_vif_df = pd.DataFrame(outer_vif_rows)

    def get_summary_reports(self):
        """Compiles all structural and measurement outputs into structured DataFrames."""
        # Path Coefficients Table
        path_rows = []
        for iv in IV_NAMES:
            path_rows.append({
                "Path": f"{iv} -> {DV_NAME}",
                "Exogenous": iv,
                "Endogenous": DV_NAME,
                "Path_Coefficient_Beta": round(self.path_coefficients[iv], 4)
            })
        path_df = pd.DataFrame(path_rows)

        # R2 Table
        r2_df = pd.DataFrame([{
            "Endogenous_Construct": DV_NAME,
            "R2 (Coefficient of Determination)": round(self.r2, 4),
            "Adjusted_R2": round(self.adj_r2, 4),
            "RMSE": round(self.rmse, 4),
            "MAE": round(self.mae, 4),
            "Target_Research_Interest": "R2 ~ 0.85 (Exploratory Benchmarking)",
            "Observed_Explanatory_Power": f"{self.r2 * 100:.2f}% of variance explained",
            "Methodological_Note": "Observed empirical value reported transparently without artificial inflation."
        }])

        return {
            "path_df": path_df,
            "r2_df": r2_df,
            "f2_df": self.f2_df,
            "q2_df": self.q2_df,
            "vif_df": self.vif_df,
            "outer_vif_df": self.outer_vif_df,
            "latent_scores": self.latent_scores,
            "outer_loadings": self.outer_loadings,
            "outer_weights": self.outer_weights
        }


if __name__ == "__main__":
    from data_preprocessing import DataPreprocessor
    prep = DataPreprocessor()
    res = prep.run_full_preprocessing_pipeline()
    pls = PlsSemModel(res['cleaned_data'])
    pls.fit_model()
    reports = pls.get_summary_reports()
    print("Path Coefficients:\n", reports['path_df'])
    print("\nR2 Summary:\n", reports['r2_df'])
    print("\nf2 Effect Sizes:\n", reports['f2_df'])
    print("\nQ2 Predictive Relevance:\n", reports['q2_df'])
    print("\nInner VIF:\n", reports['vif_df'])

