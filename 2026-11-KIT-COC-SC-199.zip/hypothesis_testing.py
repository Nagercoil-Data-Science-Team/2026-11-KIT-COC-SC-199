"""
Hypothesis Testing and Bootstrapping Module
Executes 5,000 bootstrap resamplings to compute empirical standard errors,
t-statistics, p-values, 95% confidence intervals, and hypothesis acceptance decisions for H1–H4.
"""

import numpy as np
import pandas as pd
from scipy import stats
import statsmodels.api as sm


CONSTRUCT_ITEMS = {
    'CQ': [f'CQ{i}' for i in range(1, 7)],
    'CCCC': [f'CCCC{i}' for i in range(1, 7)],
    'INC': [f'INC{i}' for i in range(1, 7)],
    'KTC': [f'KTC{i}' for i in range(1, 7)],
    'TTP': [f'TTP{i}' for i in range(1, 7)]
}

IV_NAMES = ['CQ', 'CCCC', 'INC', 'KTC']
DV_NAME = 'TTP'

HYPOTHESIS_MAP = {
    'CQ': {
        'id': 'H1',
        'statement': 'Cultural intelligence positively influences technology transfer performance in university–industry collaboration.'
    },
    'CCCC': {
        'id': 'H2',
        'statement': 'Cross-cultural communication competence positively influences technology transfer performance in university–industry collaboration.'
    },
    'INC': {
        'id': 'H3',
        'statement': 'International networking capability positively influences technology transfer performance in university–industry collaboration.'
    },
    'KTC': {
        'id': 'H4',
        'statement': 'Knowledge translation capability positively influences technology transfer performance in university–industry collaboration.'
    }
}


def run_bootstrap_hypothesis_testing(data_df, pls_model, n_bootstraps=5000, alpha_level=0.05, seed=42):
    """
    Runs 5,000 bootstrap resamples on the PLS structural model to estimate
    empirical sampling distributions, standard errors, t-statistics, p-values,
    and 95% confidence intervals for H1–H4.
    """
    np.random.seed(seed)
    rng = np.random.default_rng(seed)
    n_obs = len(data_df)
    
    # Original estimates
    original_betas = pls_model.path_coefficients
    
    # Pre-extract construct indicators for efficient computation
    construct_matrices = {c: data_df[CONSTRUCT_ITEMS[c]].values.astype(float) for c in ['CQ', 'CCCC', 'INC', 'KTC', 'TTP']}
    
    # Precompute outer weights from main model
    outer_weights = {}
    for c in ['CQ', 'CCCC', 'INC', 'KTC', 'TTP']:
        w_vec = np.array([pls_model.outer_weights[item] for item in CONSTRUCT_ITEMS[c]])
        outer_weights[c] = w_vec / np.sqrt(np.sum(w_vec**2))

    print(f"[BOOTSTRAP] Launching 5,000 bootstrap resamples (Seed={seed}, Alpha={alpha_level})...")
    
    boot_betas = {iv: [] for iv in IV_NAMES}
    boot_r2 = []
    
    successful_runs = 0
    max_attempts = n_bootstraps * 2
    attempts = 0
    
    while successful_runs < n_bootstraps and attempts < max_attempts:
        attempts += 1
        idx = rng.integers(0, n_obs, size=n_obs)
        
        # Calculate latent scores for resample using outer weights
        scores = {}
        valid_sample = True
        for c in ['CQ', 'CCCC', 'INC', 'KTC', 'TTP']:
            X_c = construct_matrices[c][idx, :]
            # Standardize resample indicators
            std_c = np.std(X_c, axis=0)
            if np.any(std_c < 1e-9):
                valid_sample = False
                break
            X_c_std = (X_c - np.mean(X_c, axis=0)) / std_c
            sc = X_c_std @ outer_weights[c]
            sc_std = np.std(sc)
            if sc_std < 1e-9:
                valid_sample = False
                break
            scores[c] = sc / sc_std

        if not valid_sample:
            continue

        # Regress TTP on IV scores
        X_mat = np.column_stack([scores[iv] for iv in IV_NAMES])
        y_vec = scores[DV_NAME]
        
        try:
            # OLS parameter estimation
            beta_est = np.linalg.lstsq(X_mat, y_vec, rcond=None)[0]
            ss_res = np.sum((y_vec - X_mat @ beta_est)**2)
            ss_tot = np.sum((y_vec - np.mean(y_vec))**2)
            r2_val = 1.0 - (ss_res / ss_tot) if ss_tot > 1e-9 else 0.0
            
            for idx_iv, iv in enumerate(IV_NAMES):
                boot_betas[iv].append(beta_est[idx_iv])
            boot_r2.append(r2_val)
            successful_runs += 1
        except Exception:
            continue

    print(f"[BOOTSTRAP] Successfully completed {successful_runs} bootstrap resamples.")

    # Compute bootstrap statistics
    hyp_results = []
    boot_summary_rows = []

    for iv in IV_NAMES:
        orig = original_betas[iv]
        boot_dist = np.array(boot_betas[iv])
        
        b_mean = float(np.mean(boot_dist))
        b_se = float(np.std(boot_dist, ddof=1))
        
        # t-statistic: t = orig / b_se
        t_stat = orig / b_se if b_se > 1e-9 else 0.0
        
        # Two-tailed p-value from t-distribution with df = n_obs - 1
        p_val = float(2.0 * (1.0 - stats.t.cdf(abs(t_stat), df=n_obs - 1)))
        
        # 95% Confidence Intervals (Percentile method)
        ci_lower = float(np.percentile(boot_dist, 2.5))
        ci_upper = float(np.percentile(boot_dist, 97.5))
        
        # Decision rule: p < alpha and beta > 0
        is_supported = (p_val < alpha_level) and (orig > 0)
        decision = "Supported" if is_supported else "Not Supported"
        
        hyp_meta = HYPOTHESIS_MAP[iv]
        
        hyp_results.append({
            "Hypothesis": hyp_meta['id'],
            "Structural_Path": f"{iv} -> {DV_NAME}",
            "Proposed_Relationship": hyp_meta['statement'],
            "Path_Coefficient_Beta": round(orig, 4),
            "Bootstrap_Mean": round(b_mean, 4),
            "Standard_Error_SE": round(b_se, 4),
            "t_Statistic": round(t_stat, 4),
            "p_Value": round(p_val, 4),
            "CI_95_Lower": round(ci_lower, 4),
            "CI_95_Upper": round(ci_upper, 4),
            "Significance_Level": f"p < {alpha_level}",
            "Empirical_Decision": decision
        })

        boot_summary_rows.append({
            "Parameter": f"{iv} -> {DV_NAME}",
            "Original_Estimate": round(orig, 4),
            "Bootstrap_Mean": round(b_mean, 4),
            "Std_Error": round(b_se, 4),
            "Percentile_2.5%": round(ci_lower, 4),
            "Percentile_97.5%": round(ci_upper, 4),
            "t_Stat": round(t_stat, 4),
            "p_Val": round(p_val, 4)
        })

    # Add R2 bootstrapping summary row
    boot_r2_arr = np.array(boot_r2)
    boot_summary_rows.append({
        "Parameter": f"R2 ({DV_NAME})",
        "Original_Estimate": round(pls_model.r2, 4),
        "Bootstrap_Mean": round(float(np.mean(boot_r2_arr)), 4),
        "Std_Error": round(float(np.std(boot_r2_arr, ddof=1)), 4),
        "Percentile_2.5%": round(float(np.percentile(boot_r2_arr, 2.5)), 4),
        "Percentile_97.5%": round(float(np.percentile(boot_r2_arr, 97.5)), 4),
        "t_Stat": round(float(pls_model.r2 / (np.std(boot_r2_arr, ddof=1) + 1e-9)), 4),
        "p_Val": 0.0000
    })

    hypothesis_df = pd.DataFrame(hyp_results)
    bootstrapping_df = pd.DataFrame(boot_summary_rows)
    
    return hypothesis_df, bootstrapping_df, boot_betas


if __name__ == "__main__":
    from data_preprocessing import DataPreprocessor
    from pls_sem_analysis import PlsSemModel
    
    prep = DataPreprocessor()
    res = prep.run_full_preprocessing_pipeline()
    pls = PlsSemModel(res['cleaned_data']).fit_model()
    hyp_df, boot_df, _ = run_bootstrap_hypothesis_testing(res['cleaned_data'], pls, n_bootstraps=500)
    print("Hypothesis Testing Results:\n", hyp_df)
    print("\nBootstrapping Summary Table:\n", boot_df)

