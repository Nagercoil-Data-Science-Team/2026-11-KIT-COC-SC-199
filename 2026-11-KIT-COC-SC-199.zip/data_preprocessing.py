"""
Data Preprocessing Module
Implements comprehensive preprocessing, screening, validation, descriptive statistics,
common method bias (CMB) assessment, and preprocessing audit logging.
"""

import os
import numpy as np
import pandas as pd
from scipy import stats
from sklearn.decomposition import PCA


CONSTRUCT_ITEMS = {
    'CQ': [f'CQ{i}' for i in range(1, 7)],
    'CCCC': [f'CCCC{i}' for i in range(1, 7)],
    'INC': [f'INC{i}' for i in range(1, 7)],
    'KTC': [f'KTC{i}' for i in range(1, 7)],
    'TTP': [f'TTP{i}' for i in range(1, 7)]
}

ALL_INDICATORS = [item for items in CONSTRUCT_ITEMS.values() for item in items]
DEMOGRAPHIC_COLS = ['Gender', 'Age_Group', 'Education', 'Professional_Position', 'Institution_Type']


class DataPreprocessor:
    def __init__(self, data_path="data/questionnaire_data.csv", log_dir="Results/Logs"):
        self.data_path = data_path
        self.log_dir = log_dir
        os.makedirs(self.log_dir, exist_ok=True)
        self.log_file = os.path.join(self.log_dir, "data_preprocessing_log.txt")
        self.log_entries = []
        self.raw_df = None
        self.cleaned_df = None
        self.is_template_data = False

    def log(self, message):
        """Append to in-memory log and print to stdout."""
        entry = f"[PREPROCESS] {message}"
        self.log_entries.append(entry)
        print(entry)

    def save_log_to_file(self):
        """Write all accumulated log entries to the log file."""
        with open(self.log_file, "w", encoding="utf-8") as f:
            f.write("=" * 80 + "\n")
            f.write("DATA PREPROCESSING & SCREENING AUDIT LOG\n")
            f.write("Research Title: How Do Cross-Cultural Boundary Spanners Drive Technology Transfer?\n")
            f.write("=" * 80 + "\n\n")
            f.write("\n".join(self.log_entries))
            f.write("\n\n" + "=" * 80 + "\n")
            f.write("END OF LOG\n")

    def load_dataset(self):
        """Load dataset from CSV or Excel, validate columns, and detect empirical vs baseline status."""
        self.log(f"Attempting to load dataset from: {self.data_path}")
        
        if not os.path.exists(self.data_path):
            xlsx_alt = self.data_path.replace('.csv', '.xlsx')
            if os.path.exists(xlsx_alt):
                self.data_path = xlsx_alt
            else:
                self.log(f"Specified dataset '{self.data_path}' not found on disk.")
                self.log("Invoking baseline template generator to initialize data structure for pipeline testing...")
                from data_generator import generate_baseline_quantitative_dataset
                generate_baseline_quantitative_dataset(self.data_path, n_participants=450)
                self.is_template_data = True
                self.log("STATUS: Processed baseline verification template. Awaiting user's field collection data.")

        # Load file
        if self.data_path.endswith('.xlsx') or self.data_path.endswith('.xls'):
            self.raw_df = pd.read_excel(self.data_path)
        else:
            self.raw_df = pd.read_csv(self.data_path)

        self.log(f"Dataset successfully loaded. Total rows: {len(self.raw_df)}, Total columns: {self.raw_df.shape[1]}")
        
        # Verify required indicators
        missing_indicators = [col for col in ALL_INDICATORS if col not in self.raw_df.columns]
        if missing_indicators:
            raise ValueError(f"Dataset is missing required measurement items: {missing_indicators}")
        self.log(f"All 30 measurement items verified across 5 constructs (CQ, CCCC, INC, KTC, TTP).")

        return self.raw_df

    def identify_duplicates(self, df):
        """Identify and document duplicate responses."""
        initial_count = len(df)
        dup_indicators = df.duplicated(subset=ALL_INDICATORS, keep='first')
        n_duplicates = dup_indicators.sum()
        self.log(f"Duplicate response check: Found {n_duplicates} duplicate records based on survey item responses.")
        
        if n_duplicates > 0:
            df = df.drop_duplicates(subset=ALL_INDICATORS, keep='first').reset_index(drop=True)
            self.log(f"Exclusion: Removed {n_duplicates} duplicate rows. Remaining valid sample size: {len(df)}")
        else:
            self.log("No duplicate responses identified. All records are distinct.")
        return df

    def analyze_and_treat_missing_values(self, df):
        """Analyze missing values and apply methodological treatment."""
        missing_counts = df[ALL_INDICATORS].isna().sum()
        total_missing = missing_counts.sum()
        pct_missing = (total_missing / (len(df) * len(ALL_INDICATORS))) * 100
        
        self.log(f"Missing-value analysis: Total missing cells across indicators = {total_missing} ({pct_missing:.3f}%).")
        
        if total_missing > 0:
            self.log(f"Missing values detected. Detailed missingness per item:\n{missing_counts[missing_counts > 0]}")
            # Methodological treatment: Median imputation for missing values when < 5%
            if pct_missing <= 5.0:
                self.log("Treatment applied: Median imputation applied for indicators with missing values (< 5% threshold).")
                for col in ALL_INDICATORS:
                    if df[col].isna().sum() > 0:
                        median_val = df[col].median()
                        df[col] = df[col].fillna(median_val)
            else:
                self.log("Treatment applied: Missing values exceed 5%; employing listwise deletion of incomplete cases.")
                df = df.dropna(subset=ALL_INDICATORS).reset_index(drop=True)
        else:
            self.log("Missing-data check: Dataset is 100% complete with 0 missing values across all items.")

        return df

    def validate_likert_scale(self, df):
        """Validate that all Likert responses are within 1 to 5."""
        out_of_bounds = {}
        for col in ALL_INDICATORS:
            invalid = df[(df[col] < 1) | (df[col] > 5) | (df[col] != df[col].round())]
            if len(invalid) > 0:
                out_of_bounds[col] = len(invalid)

        if out_of_bounds:
            self.log(f"Warning: Out-of-bounds Likert responses detected: {out_of_bounds}")
            for col, count in out_of_bounds.items():
                df[col] = df[col].clip(1, 5).round().astype(int)
            self.log("Treatment: Clipped out-of-range values to valid Likert bounds [1, 5].")
        else:
            self.log("Likert-scale validation: All 30 items strictly conform to integer values within [1, 5].")

        return df

    def screen_response_quality_and_outliers(self, df):
        """
        Screen for straight-lining (zero variance) and unengaged responses,
        plus multivariate outlier detection via Mahalanobis Distance.
        """
        # 1. Straight-lining / zero variance across survey items
        item_variances = df[ALL_INDICATORS].var(axis=1)
        straight_liners = df[item_variances == 0]
        n_straight = len(straight_liners)
        self.log(f"Response quality screening (Straight-lining): Found {n_straight} cases with zero variance across all 30 items.")
        
        if n_straight > 0:
            df = df[item_variances > 0].reset_index(drop=True)
            self.log(f"Exclusion criteria: Removed {n_straight} unengaged straight-lining responses.")

        # 2. Multivariate outlier detection using Mahalanobis Distance
        X = df[ALL_INDICATORS].values.astype(float)
        mean_vec = np.mean(X, axis=0)
        cov_mat = np.cov(X, rowvar=False)
        cov_inv = np.linalg.pinv(cov_mat)
        
        diff = X - mean_vec
        md_sq = np.sum((diff @ cov_inv) * diff, axis=1)
        
        # Chi-square cutoff at alpha=0.001 with df=30
        cutoff = stats.chi2.ppf(0.999, df=len(ALL_INDICATORS))
        outliers = np.where(md_sq > cutoff)[0]
        self.log(f"Multivariate outlier analysis (Mahalanobis Distance): Chi-sq cutoff (p=0.001, df=30) = {cutoff:.2f}. Found {len(outliers)} severe multivariate outliers.")
        
        # In research-grade protocols, we document outliers rather than discarding valid responses arbitrarily
        self.log(f"Methodological decision: Retaining all {len(df)} screened eligible respondents to maintain sample integrity and prevent artificial distribution skewing.")
        
        return df

    def check_reverse_coded_items(self, df):
        """
        Verify if any measurement items require reverse coding.
        Checks correlation of each item with construct total.
        """
        reverse_candidates = []
        for construct, items in CONSTRUCT_ITEMS.items():
            construct_sum = df[items].sum(axis=1)
            for item in items:
                corr, _ = stats.pearsonr(df[item], construct_sum - df[item])
                if corr < 0:
                    reverse_candidates.append((construct, item, corr))

        if reverse_candidates:
            self.log(f"Reverse-coding alert: Negative item-total correlations found: {reverse_candidates}")
        else:
            self.log("Reverse-coded item check: All 30 items demonstrate positive item-total correlations. No reverse-coding required.")

        return reverse_candidates

    def compute_descriptive_statistics(self, df):
        """Calculate Mean, SD, Median, Min, Max, Skewness, Kurtosis for items and constructs."""
        stats_rows = []
        
        # 1. Item-level descriptives
        for construct, items in CONSTRUCT_ITEMS.items():
            for item in items:
                series = df[item]
                stats_rows.append({
                    "Variable_Type": "Indicator",
                    "Construct": construct,
                    "Item_Code": item,
                    "Mean": round(series.mean(), 3),
                    "Std_Dev": round(series.std(), 3),
                    "Median": round(series.median(), 3),
                    "Min": int(series.min()),
                    "Max": int(series.max()),
                    "Skewness": round(stats.skew(series), 3),
                    "Kurtosis": round(stats.kurtosis(series), 3)
                })

        # 2. Construct-level composite descriptives
        for construct, items in CONSTRUCT_ITEMS.items():
            comp_series = df[items].mean(axis=1)
            stats_rows.append({
                "Variable_Type": "Construct Composite",
                "Construct": construct,
                "Item_Code": f"{construct}_Mean",
                "Mean": round(comp_series.mean(), 3),
                "Std_Dev": round(comp_series.std(), 3),
                "Median": round(comp_series.median(), 3),
                "Min": round(comp_series.min(), 3),
                "Max": round(comp_series.max(), 3),
                "Skewness": round(stats.skew(comp_series), 3),
                "Kurtosis": round(stats.kurtosis(comp_series), 3)
            })

        desc_df = pd.DataFrame(stats_rows)
        self.log(f"Descriptive statistics computed for all 30 indicators and 5 construct composites.")
        return desc_df

    def assess_common_method_bias(self, df):
        """
        Assess Common Method Bias using:
        1. Harman's Single Factor Test (Unrotated PCA)
        2. Full Collinearity VIF screening (evaluated in structural modeling)
        """
        X = df[ALL_INDICATORS].values
        pca = PCA(n_components=1)
        pca.fit(X)
        first_factor_var = pca.explained_variance_ratio_[0] * 100
        
        self.log(f"Harman's Single-Factor Test (Unrotated PCA): First factor explains {first_factor_var:.2f}% of total variance.")
        if first_factor_var < 50.0:
            self.log(f"CMB Threshold Check: PASSED ({first_factor_var:.2f}% < 50.0%). Common method variance does not represent a significant threat to data validity (Podsakoff et al., 2003).")
        else:
            self.log(f"CMB Threshold Check: WARNING ({first_factor_var:.2f}% >= 50.0%). First factor accounts for the majority of variance.")

        cmb_summary = {
            "Method": "Harman's Single Factor Test (Unrotated PCA)",
            "First_Factor_Variance_Pct": round(first_factor_var, 3),
            "Threshold": "< 50.0%",
            "Result": "Passed (No pervasive CMB)" if first_factor_var < 50.0 else "Warning (Elevated CMB)"
        }
        return cmb_summary

    def analyze_demographics(self, df):
        """Generate demographic frequency and percentage tables."""
        demographic_tables = {}
        for col in DEMOGRAPHIC_COLS:
            if col in df.columns:
                counts = df[col].value_counts()
                pcts = (counts / len(df)) * 100
                demo_table = pd.DataFrame({
                    "Category": counts.index,
                    "Frequency": counts.values,
                    "Percentage": pcts.round(2).values
                })
                demographic_tables[col] = demo_table
                self.log(f"Demographic distribution for '{col}': {len(demo_table)} categories analyzed (N={len(df)}).")
        return demographic_tables

    def run_full_preprocessing_pipeline(self):
        """Execute complete preprocessing pipeline."""
        df = self.load_dataset()
        df = self.identify_duplicates(df)
        df = self.analyze_and_treat_missing_values(df)
        df = self.validate_likert_scale(df)
        df = self.screen_response_quality_and_outliers(df)
        self.check_reverse_coded_items(df)
        
        desc_df = self.compute_descriptive_statistics(df)
        cmb_results = self.assess_common_method_bias(df)
        demographics = self.analyze_demographics(df)
        
        self.cleaned_df = df
        self.save_log_to_file()
        
        return {
            "cleaned_data": df,
            "descriptive_stats": desc_df,
            "cmb_results": cmb_results,
            "demographics": demographics,
            "log_entries": self.log_entries,
            "is_template_data": self.is_template_data
        }


if __name__ == "__main__":
    preprocessor = DataPreprocessor()
    res = preprocessor.run_full_preprocessing_pipeline()
    print("Preprocessing completed successfully. Cleaned shape:", res['cleaned_data'].shape)

